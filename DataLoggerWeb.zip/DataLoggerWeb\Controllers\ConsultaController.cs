using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

/// <summary>
/// Consulta das mensagens IoT (histórico do STH-Comet) via Ajax.
/// </summary>
public class ConsultaController : Controller
{
    private readonly DispositivoDAO dispositivoDAO = new();
    private readonly HistoricoDAO historicoDAO = new();

    public async Task<IActionResult> Index()
    {
        try
        {
            ViewBag.Dispositivos = await dispositivoDAO.ListagemAsync();
            return View(new ConsultaViewModel());
        }
        catch (Exception erro)
        {
            return View("Error", new ErrorViewModel(erro.Message));
        }
    }

    /// <summary>Chamado via Ajax: devolve a partial com a tabela ou um JSON de erro.</summary>
    [HttpGet]
    public async Task<IActionResult> ObtemDadosConsulta(ConsultaViewModel filtro)
    {
        try
        {
            string? erro = ValidaFiltro(filtro);
            if (erro != null)
                return Json(new { erro = true, msg = erro });

            var dispositivo = await dispositivoDAO.ConsultaAsync(filtro.DispositivoId!);
            if (dispositivo == null)
                return Json(new { erro = true, msg = "Dispositivo não encontrado no IoT Agent." });

            var atributos = dispositivo.Atributos.Select(a => a.Nome).ToList();
            if (!string.IsNullOrEmpty(filtro.Atributo))
            {
                if (!atributos.Contains(filtro.Atributo))
                    return Json(new { erro = true, msg = "Atributo não pertence ao dispositivo." });
                atributos = [filtro.Atributo];
            }

            var mensagens = await historicoDAO.ConsultaVariosAsync(dispositivo, atributos,
                filtro.Quantidade, filtro.DataInicial, filtro.DataFinal);

            return PartialView("pvGridMensagens", mensagens);
        }
        catch (Exception erro)
        {
            return Json(new { erro = true, msg = erro.Message });
        }
    }

    private static string? ValidaFiltro(ConsultaViewModel filtro)
    {
        if (string.IsNullOrWhiteSpace(filtro.DispositivoId))
            return "Selecione um dispositivo.";
        if (filtro.Quantidade is < 1 or > HistoricoDAO.MaximoRegistros)
            return $"A quantidade deve estar entre 1 e {HistoricoDAO.MaximoRegistros}.";
        if (filtro.DataInicial > filtro.DataFinal)
            return "A data inicial deve ser anterior à data final.";
        if (filtro.DataInicial > DateTime.Now)
            return "A data inicial não pode estar no futuro.";
        return null;
    }
}
