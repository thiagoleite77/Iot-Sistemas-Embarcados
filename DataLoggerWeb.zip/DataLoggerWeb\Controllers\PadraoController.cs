using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

/// <summary>
/// Controller genérico com o CRUD padrão (Index, Create, Edit, Save e Delete).
/// Os controllers filhos informam apenas o DAO e as validações específicas.
/// Operação: "I" = inclusão | "A" = alteração
/// </summary>
public abstract class PadraoController<T> : Controller where T : PadraoViewModel, new()
{
    protected readonly PadraoDAO<T> DAO;
    protected string NomeViewIndex { get; set; } = "Index";
    protected string NomeViewForm { get; set; } = "Form";

    protected PadraoController(PadraoDAO<T> dao) => DAO = dao;

    public virtual async Task<IActionResult> Index()
    {
        try
        {
            return View(NomeViewIndex, await DAO.ListagemAsync());
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }
    }

    public virtual async Task<IActionResult> Create()
    {
        try
        {
            ViewBag.Operacao = "I";
            var model = CriaModelPadrao();
            await PreencheDadosParaView("I", model);
            return View(NomeViewForm, model);
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }
    }

    public virtual async Task<IActionResult> Edit(string id)
    {
        try
        {
            var model = await DAO.ConsultaAsync(id);
            if (model == null)
            {
                TempData["Erro"] = $"Registro '{id}' não encontrado no FIWARE.";
                return RedirectToAction(NomeViewIndex);
            }

            ViewBag.Operacao = "A";
            await PreencheDadosParaView("A", model);
            return View(NomeViewForm, model);
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public virtual async Task<IActionResult> Save(T model, string operacao)
    {
        if (operacao is not ("I" or "A"))
            return TrataErro(new ArgumentException("Operação inválida."));

        try
        {
            await ValidaDados(model, operacao);
            if (ModelState.IsValid)
            {
                if (operacao == "I")
                    await DAO.InsertAsync(model);
                else
                    await DAO.UpdateAsync(model);

                TempData["Sucesso"] = operacao == "I"
                    ? "Registro incluído no FIWARE com sucesso!"
                    : "Registro alterado no FIWARE com sucesso!";

                await AposSalvar(model, operacao);
                return RedirectToAction(NomeViewIndex);
            }
        }
        catch (FiwareException erro)
        {
            // Erro devolvido pela API (ex.: id duplicado): mostra no próprio formulário
            ModelState.AddModelError(string.Empty, erro.Message);
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }

        try
        {
            ViewBag.Operacao = operacao;
            await PreencheDadosParaView(operacao, model);
            return View(NomeViewForm, model);
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public virtual async Task<IActionResult> Delete(string id)
    {
        try
        {
            await DAO.DeleteAsync(id);
            TempData["Sucesso"] = "Registro excluído do FIWARE com sucesso!";
        }
        catch (Exception erro)
        {
            TempData["Erro"] = erro.Message;
        }
        return RedirectToAction(NomeViewIndex);
    }

    /// <summary>Model exibido na tela de inclusão (sobrescreva para trazer valores padrão).</summary>
    protected virtual T CriaModelPadrao() => new();

    /// <summary>Carrega dados extras para o formulário (ex.: listas de seleção). Sobrescreva se precisar.</summary>
    protected virtual Task PreencheDadosParaView(string operacao, T model) => Task.CompletedTask;

    /// <summary>Executado depois de uma inclusão/alteração bem-sucedida.</summary>
    protected virtual Task AposSalvar(T model, string operacao) => Task.CompletedTask;

    protected virtual async Task ValidaDados(T model, string operacao)
    {
        ModelState.Clear();

        if (!HelperControllers.IdentificadorValido(model.Id))
            ModelState.AddModelError(nameof(model.Id), "Informe um identificador válido (letras, números, _ - : . e sem espaços).");
        else if (operacao == "I" && await DAO.ConsultaAsync(model.Id) != null)
            ModelState.AddModelError(nameof(model.Id), "Já existe um registro com este identificador no FIWARE.");
        else if (operacao == "A" && await DAO.ConsultaAsync(model.Id) == null)
            ModelState.AddModelError(nameof(model.Id), "Este registro não existe mais no FIWARE.");
    }

    protected IActionResult TrataErro(Exception erro) => View("Error", new ErrorViewModel(erro.Message));
}
