namespace DataLoggerWeb.DAO;

/// <summary>
/// Configurações de acesso ao FIWARE (preenchidas a partir do appsettings.json).
/// </summary>
public class FiwareConfig
{
    public string Host { get; set; } = "localhost";
    public int PortaOrion { get; set; } = 1026;
    public int PortaIoTAgent { get; set; } = 4041;
    public int PortaSth { get; set; } = 8666;
    public string FiwareService { get; set; } = "smart";
    public string FiwareServicePath { get; set; } = "/";
    public int TimeoutSegundos { get; set; } = 10;

    // Endereços vistos DE DENTRO do docker (usados pelo IoT Agent e pelas assinaturas do Orion)
    public string UrlOrionInterna { get; set; } = "http://orion:1026";
    public string UrlSthInterna { get; set; } = "http://sth-comet:8666";
}
