using System.Text;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Consulta o histórico de mensagens IoT gravado no STH-Comet.
/// </summary>
public class HistoricoDAO
{
    /// <summary>Limite do STH-Comet: lastN aceita no máximo 100 valores por consulta.</summary>
    public const int MaximoRegistros = 100;

    public async Task<List<MensagemIoTViewModel>> ConsultaAsync(DispositivoViewModel dispositivo, string atributo,
        int quantidade, DateTime? dataInicial = null, DateTime? dataFinal = null)
    {
        var url = new StringBuilder($"{HelperFiware.UrlSth}/STH/v1/contextEntities")
            .Append($"/type/{Uri.EscapeDataString(dispositivo.EntityType)}")
            .Append($"/id/{Uri.EscapeDataString(dispositivo.EntityName)}")
            .Append($"/attributes/{Uri.EscapeDataString(atributo)}")
            .Append($"?lastN={quantidade}");

        if (dataInicial.HasValue)
            url.Append($"&dateFrom={HelperFiware.FormataDataIso(dataInicial.Value)}");
        if (dataFinal.HasValue)
            url.Append($"&dateTo={HelperFiware.FormataDataIso(dataFinal.Value)}");

        var resposta = await HelperFiware.GetAsync(url.ToString(), nullSeNaoEncontrado: true);

        // contextResponses[0].contextElement.attributes[0].values[]
        var valores = (resposta.Lista("contextResponses").FirstOrDefault()?["contextElement"])
            .Lista("attributes").FirstOrDefault()
            .Lista("values");

        return valores.Select(v => new MensagemIoTViewModel
        {
            DataHora = v.DataHora("recvTime") ?? DateTime.MinValue,
            DispositivoId = dispositivo.Id,
            EntidadeId = dispositivo.EntityName,
            Atributo = atributo,
            Tipo = v.Texto("attrType"),
            Valor = v.Texto("attrValue")
        }).ToList();
    }

    /// <summary>Consulta vários atributos em paralelo e junta tudo, do mais recente para o mais antigo.</summary>
    public async Task<List<MensagemIoTViewModel>> ConsultaVariosAsync(DispositivoViewModel dispositivo,
        IEnumerable<string> atributos, int quantidade, DateTime? dataInicial = null, DateTime? dataFinal = null)
    {
        var resultados = await Task.WhenAll(
            atributos.Select(a => ConsultaAsync(dispositivo, a, quantidade, dataInicial, dataFinal)));

        return resultados.SelectMany(lista => lista).OrderByDescending(m => m.DataHora).ToList();
    }
}
