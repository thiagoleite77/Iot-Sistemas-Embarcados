using System.Text.Json.Nodes;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Acesso às entidades do Orion (/v2/entities): valores atuais, comandos e exclusão.
/// </summary>
public class EntidadeDAO
{
    private static string UrlEntidade(string id) => $"{HelperFiware.UrlOrion}/v2/entities/{Uri.EscapeDataString(id)}";

    /// <summary>Última leitura de cada atributo (formato keyValues). Vazio se a entidade não existir.</summary>
    public async Task<Dictionary<string, string>> ConsultaValoresAtuaisAsync(string entityId, string entityType)
    {
        var json = await HelperFiware.GetAsync(
            $"{UrlEntidade(entityId)}?type={Uri.EscapeDataString(entityType)}&options=keyValues",
            nullSeNaoEncontrado: true) as JsonObject;

        return json?
            .Where(propriedade => propriedade.Key is not ("id" or "type"))
            .ToDictionary(propriedade => propriedade.Key, propriedade => propriedade.Value?.ToString() ?? string.Empty)
            ?? new Dictionary<string, string>();
    }

    /// <summary>
    /// Envia um comando ao dispositivo. O IoT Agent repassa via MQTT no formato UltraLight:
    /// &lt;device_id&gt;@&lt;comando&gt;|&lt;valor&gt; (ex.: env001@alerta|1).
    /// </summary>
    public Task EnviaComandoAsync(string entityId, string entityType, string comando, string valor = "") =>
        HelperFiware.PatchAsync(
            $"{UrlEntidade(entityId)}/attrs?type={Uri.EscapeDataString(entityType)}",
            new JsonObject { [comando] = new JsonObject { ["type"] = "command", ["value"] = valor } });

    /// <summary>
    /// Grava um valor de atributo direto no Orion, como se fosse uma leitura do dispositivo
    /// (usado pelos botões de teste do dashboard). O POST em /attrs cria ou atualiza o atributo,
    /// e a assinatura do STH-Comet grava o valor no histórico.
    /// </summary>
    public Task GravaLeituraAsync(string entityId, string entityType, string atributo, string tipo, double valor) =>
        HelperFiware.PostAsync(
            $"{UrlEntidade(entityId)}/attrs?type={Uri.EscapeDataString(entityType)}",
            new JsonObject
            {
                [atributo] = new JsonObject
                {
                    ["type"] = tipo,
                    ["value"] = tipo == "Integer" ? JsonValue.Create((int)Math.Round(valor)) : JsonValue.Create(Math.Round(valor, 1))
                },
                // Mantém o horário da "última leitura" coerente, como o IoT Agent faz
                ["TimeInstant"] = new JsonObject { ["type"] = "DateTime", ["value"] = HelperFiware.FormataDataIso(DateTime.Now) }
            });

    public Task DeleteAsync(string entityId, string entityType) =>
        HelperFiware.DeleteAsync($"{UrlEntidade(entityId)}?type={Uri.EscapeDataString(entityType)}", ignoraNaoEncontrado: true);
}
