# Data Logger IoT – Manual de uso

Resumo de cada tela do site. A configuração inicial está no [MANUAL_CONFIGURACAO.md](MANUAL_CONFIGURACAO.md).

## Elementos comuns
- **Menu superior:** leva a todas as telas; à direita aparece o endereço do FIWARE em uso.
- **Mensagens:** faixa verde confirma uma operação; faixa vermelha explica o erro. Exclusões sempre pedem confirmação.

## Telas

| Tela | Para que serve |
|---|---|
| **Início** | Mostra se Orion, IoT Agent e STH-Comet estão online e os totais cadastrados. O card da AWS exibe o IP da EC2, com o botão **Atualizar IP pela AWS**. |
| **Dispositivos** | Lista os ESP32 cadastrados no IoT Agent, com filtro rápido. Ações: detalhes (olho), alterar (lápis), criar assinaturas que faltam (sino) e excluir (lixeira). |
| **Novo / Alterar dispositivo** | Cadastra o Device ID, a API Key, a entidade e os atributos que o ESP32 envia (object_id, nome e tipo). Na inclusão, cria sozinho as assinaturas do histórico, uma por atributo. |
| **Detalhes do dispositivo** | Mostra os últimos valores, o tópico MQTT e um exemplo de payload para o firmware. Envia comandos com valor ao ESP32; no `alerta`, um índice mostra o que cada código sinaliza (0 normal, 1 temperatura, 2 umidade, 3 luminosidade). |
| **Service Groups** | Lista as API Keys que o IoT Agent aceita nos tópicos MQTT e se o autoprovisionamento está ligado. Permite criar, alterar e excluir. |
| **Novo / Alterar service group** | Define a API Key e o endereço do Orion usado pelo IoT Agent. A API Key precisa ser igual à do firmware. |
| **Assinaturas** | Lista as assinaturas do Orion com destino, status e quantas notificações já foram enviadas. Se "Notificações" cresce, o histórico está sendo gravado. |
| **Nova / Alterar assinatura** | Cria ou edita uma assinatura manualmente; no formato STH-Comet, é um atributo por assinatura. Normalmente não é necessário, porque o cadastro do dispositivo já cria. |
| **Consulta IoT** | Pesquisa o histórico por dispositivo, atributo, período e quantidade (até 100), sem recarregar a página. Mostra mínimo, média e máximo e exporta para CSV. |
| **Dashboard – painel de alertas** | Compara a média das últimas leituras com os limites e envia sozinho o código do alerta ao ESP32 (ou 0 na normalidade). O botão **Testar alerta** de cada grandeza grava leituras fora do limite para demonstrar. |
| **Dashboard – valores e gráficos** | Cards com os valores atuais, gráfico do histórico e gráfico de mínimo, média e máximo por período. Atualiza sozinho a cada 10 s (chave **Auto**). |
| **Erro** | Aparece quando o FIWARE não responde ou uma operação falha, explicando o motivo. Use **Voltar** ou **Voltar ao início**. |
