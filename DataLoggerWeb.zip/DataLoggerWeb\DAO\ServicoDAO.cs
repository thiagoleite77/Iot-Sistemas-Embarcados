using System.Text.Json.Nodes;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// CRUD de Service Groups no IoT Agent (/iot/services).
/// O service group define a API Key usada nos tópicos MQTT (/apikey/device_id/attrs).
/// </summary>
public class ServicoDAO : PadraoDAO<ServicoViewModel>
{
    protected override string Url => $"{HelperFiware.UrlIoTAgent}/iot/services";

    protected override JsonArray? ExtraiLista(JsonNode? resposta) => resposta?["services"] as JsonArray;

    protected override ServicoViewModel MontaModel(JsonNode registro) => new()
    {
        Id = registro.Texto("apikey"),
        Resource = registro.Texto("resource"),
        Cbroker = registro.Texto("cbroker"),
        EntityType = registro.Texto("entity_type"),
        Autoprovision = bool.TryParse(registro.Texto("autoprovision"), out bool autoprovision) ? autoprovision : null
    };

    // autoprovision false: mensagem de um device_id/apikey não cadastrado é descartada, em vez
    // de criar um dispositivo "fantasma" com outra entidade (como no FIWARE Made Simple)
    protected override JsonObject CriaJson(ServicoViewModel model) => new()
    {
        ["apikey"] = model.Id,
        ["cbroker"] = model.Cbroker,
        ["entity_type"] = model.EntityType,
        ["resource"] = model.Resource ?? string.Empty,
        ["autoprovision"] = false
    };

    // O IoT Agent identifica o service group pela dupla resource + apikey (na query string)
    private string UrlChave(ServicoViewModel model) =>
        $"{Url}?resource={Uri.EscapeDataString(model.Resource ?? string.Empty)}&apikey={Uri.EscapeDataString(model.Id)}";

    // Não existe GET por apikey na API, então filtramos a listagem
    public override async Task<ServicoViewModel?> ConsultaAsync(string id) =>
        (await ListagemAsync()).FirstOrDefault(s => s.Id == id);

    public override Task InsertAsync(ServicoViewModel model) =>
        HelperFiware.PostAsync(Url, new JsonObject { ["services"] = new JsonArray(CriaJson(model)) });

    public override Task UpdateAsync(ServicoViewModel model) =>
        HelperFiware.PutAsync(UrlChave(model), new JsonObject
        {
            ["cbroker"] = model.Cbroker,
            ["entity_type"] = model.EntityType,
            ["autoprovision"] = false   // salvar um grupo antigo também desliga o autoprovisionamento
        });

    public override async Task DeleteAsync(string id)
    {
        var servico = await ConsultaAsync(id) ?? throw new FiwareException($"Service group '{id}' não encontrado.");
        await HelperFiware.DeleteAsync(UrlChave(servico));
    }
}
