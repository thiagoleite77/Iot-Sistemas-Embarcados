namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Service Group do IoT Agent. Id = apikey.
/// </summary>
public class ServicoViewModel : PadraoViewModel
{
    public string? Resource { get; set; }
    public string Cbroker { get; set; } = string.Empty;
    public string EntityType { get; set; } = string.Empty;

    /// <summary>
    /// Autoprovisionamento do IoT Agent (somente leitura). Ligado (ou null), mensagens de
    /// dispositivos não reconhecidos criam dispositivos novos; o site grava sempre false.
    /// </summary>
    public bool? Autoprovision { get; set; }
}
