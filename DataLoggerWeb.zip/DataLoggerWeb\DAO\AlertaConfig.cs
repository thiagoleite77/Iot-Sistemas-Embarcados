using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Configurações do painel de alertas (preenchidas a partir da seção "Alertas" do appsettings.json).
/// </summary>
public class AlertaConfig
{
    /// <summary>Quantidade de leituras mais recentes usadas no cálculo da média.</summary>
    public int JanelaMedia { get; set; } = 10;

    /// <summary>Quantidade de leituras analisadas para listar as ocorrências fora do limite.</summary>
    public int LeiturasOcorrencias { get; set; } = 50;

    /// <summary>Nome do comando de alerta cadastrado no dispositivo (igual ao firmware do ESP32).</summary>
    public string ComandoAlerta { get; set; } = "alerta";

    /// <summary>Valor do comando de alerta que significa "tudo normal" (LED e buzzer desligados).</summary>
    public int CodigoNormal { get; set; } = 0;

    /// <summary>Mostra no dashboard os botões "Testar alerta" (para a apresentação).</summary>
    public bool BotoesTeste { get; set; }

    /// <summary>Limites de cada grandeza. Prioridade 1 = mais importante.</summary>
    public List<LimiteViewModel> Limites { get; set; } = [];
}
