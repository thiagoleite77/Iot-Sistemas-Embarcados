using System.Globalization;

namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Uma leitura (mensagem IoT) armazenada no STH-Comet.
/// </summary>
public class MensagemIoTViewModel
{
    public DateTime DataHora { get; set; }
    public string DispositivoId { get; set; } = string.Empty;
    public string EntidadeId { get; set; } = string.Empty;
    public string Atributo { get; set; } = string.Empty;
    public string Tipo { get; set; } = string.Empty;
    public string Valor { get; set; } = string.Empty;

    /// <summary>Valor convertido para número (null quando o valor não é numérico).</summary>
    public double? ValorNumerico =>
        double.TryParse(Valor, NumberStyles.Float, CultureInfo.InvariantCulture, out double numero) ? numero : null;
}
