namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Filtros da tela de consulta de mensagens IoT.
/// </summary>
public class ConsultaViewModel
{
    public string? DispositivoId { get; set; }

    /// <summary>Vazio = todos os atributos do dispositivo.</summary>
    public string? Atributo { get; set; }

    public int Quantidade { get; set; } = 20;
    public DateTime? DataInicial { get; set; }
    public DateTime? DataFinal { get; set; }
}
