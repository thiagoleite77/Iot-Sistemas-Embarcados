using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

/// <summary>
/// Dashboard com cards de valores atuais (Orion) e gráficos do histórico (STH-Comet).
/// </summary>
public class DashboardController : Controller
{
    private readonly DispositivoDAO dispositivoDAO = new();
    private readonly EntidadeDAO entidadeDAO = new();
    private readonly HistoricoDAO historicoDAO = new();
    private readonly AlertaDAO alertaDAO = new();

    public async Task<IActionResult> Index(string? dispositivoId)
    {
        try
        {
            ViewBag.Dispositivos = await dispositivoDAO.ListagemAsync();
            ViewBag.Selecionado = dispositivoId;
            return View();
        }
        catch (Exception erro)
        {
            return View("Error", new ErrorViewModel(erro.Message));
        }
    }

    /// <summary>Chamado via Ajax pelo dashboard.js (também na atualização automática).</summary>
    [HttpGet]
    public async Task<IActionResult> ObtemDados(string dispositivoId, string atributo, int quantidade = 100, string agrupamento = "hora")
    {
        try
        {
            if (quantidade is < 1 or > HistoricoDAO.MaximoRegistros)
                return Json(new { erro = true, msg = $"A quantidade deve estar entre 1 e {HistoricoDAO.MaximoRegistros}." });

            var dispositivo = await dispositivoDAO.ConsultaAsync(dispositivoId ?? string.Empty);
            if (dispositivo == null)
                return Json(new { erro = true, msg = "Dispositivo não encontrado." });

            if (!dispositivo.Atributos.Any(a => a.Nome == atributo))
                return Json(new { erro = true, msg = "Atributo não pertence ao dispositivo." });

            // Orion (valor atual) e STH-Comet (histórico) consultados em paralelo
            var tarefaAtuais = entidadeDAO.ConsultaValoresAtuaisAsync(dispositivo.EntityName, dispositivo.EntityType);
            var tarefaHistorico = historicoDAO.ConsultaAsync(dispositivo, atributo, quantidade);
            var atuais = await tarefaAtuais;
            var historico = await tarefaHistorico;

            return Json(MontaDashboard(dispositivo, atuais, historico, agrupamento));
        }
        catch (Exception erro)
        {
            return Json(new { erro = true, msg = erro.Message });
        }
    }

    /// <summary>
    /// Chamado via Ajax: painel de alertas com a média das últimas leituras de
    /// cada grandeza comparada aos limites do appsettings.json.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> ObtemAlertas(string dispositivoId)
    {
        try
        {
            var dispositivo = await dispositivoDAO.ConsultaAsync(dispositivoId ?? string.Empty);
            if (dispositivo == null)
                return Json(new { erro = true, msg = "Dispositivo não encontrado." });

            return Json(await alertaDAO.ObtemPainelAsync(dispositivo));
        }
        catch (Exception erro)
        {
            return Json(new { erro = true, msg = erro.Message });
        }
    }

    /// <summary>
    /// Chamado via Ajax pelo dashboard quando o alerta ativo muda (e a cada 60 s, como reforço):
    /// envia ao ESP32 o comando de alerta com o código da grandeza, ou o código normal
    /// para desligar LED e buzzer. O ESP32 recebe, por exemplo, env001@alerta|2.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EnviaAlerta(string dispositivoId, int codigo)
    {
        try
        {
            var config = AlertaDAO.Config;
            var dispositivo = await dispositivoDAO.ConsultaAsync(dispositivoId ?? string.Empty);
            if (dispositivo == null)
                return Json(new { erro = true, msg = "Dispositivo não encontrado." });

            if (!HelperFiware.SeparaLista(dispositivo.Comandos).Contains(config.ComandoAlerta))
                return Json(new { erro = true, msg = $"O dispositivo não tem o comando '{config.ComandoAlerta}' cadastrado." });

            // Só aceita os códigos configurados: o normal e um por grandeza
            if (codigo != config.CodigoNormal && !config.Limites.Any(l => l.CodigoAlerta == codigo))
                return Json(new { erro = true, msg = $"Código de alerta inválido: {codigo}." });

            await entidadeDAO.EnviaComandoAsync(dispositivo.EntityName, dispositivo.EntityType, config.ComandoAlerta, codigo.ToString());
            return Json(new { erro = false, mensagem = $"{dispositivo.Id}@{config.ComandoAlerta}|{codigo}" });
        }
        catch (Exception erro)
        {
            return Json(new { erro = true, msg = erro.Message });
        }
    }

    /// <summary>
    /// Botão "Testar alerta" (apresentação): grava no Orion leituras fora do limite de uma
    /// grandeza, como se viessem do ESP32. O painel entra em alerta na próxima atualização
    /// e o envio automático aciona o LED e o buzzer.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SimulaAlerta(string dispositivoId, string atributo)
    {
        try
        {
            if (!AlertaDAO.Config.BotoesTeste)
                return Json(new { erro = true, msg = "Os botões de teste estão desativados (BotoesTeste no appsettings.json)." });

            var dispositivo = await dispositivoDAO.ConsultaAsync(dispositivoId ?? string.Empty);
            if (dispositivo == null)
                return Json(new { erro = true, msg = "Dispositivo não encontrado." });

            var limite = AlertaDAO.Config.Limites.FirstOrDefault(l => l.Atributo == atributo);
            if (limite == null || !dispositivo.Atributos.Any(a => a.Nome == atributo))
                return Json(new { erro = true, msg = "Esta grandeza não tem limite configurado neste dispositivo." });

            if (limite.Classifica(limite.ValorTeste) == SituacaoAlerta.Normal)
                return Json(new { erro = true, msg = $"O ValorTeste de {limite.Rotulo} ({limite.ValorTeste:0.##}) está dentro da faixa: ajuste no appsettings.json." });

            int quantidade = await alertaDAO.SimulaForaDoLimiteAsync(dispositivo, limite);
            return Json(new { erro = false, msg = $"Teste de {limite.Rotulo}: {quantidade} leituras de {limite.ValorTeste:0.##} {limite.Unidade} gravadas no Orion." });
        }
        catch (Exception erro)
        {
            return Json(new { erro = true, msg = erro.Message });
        }
    }

    private static DashboardViewModel MontaDashboard(DispositivoViewModel dispositivo, Dictionary<string, string> atuais,
        List<MensagemIoTViewModel> historico, string agrupamento)
    {
        // Apenas leituras numéricas entram nos gráficos
        var leituras = historico
            .Where(m => m.ValorNumerico.HasValue)
            .Select(m => (m.DataHora, Valor: m.ValorNumerico!.Value))
            .OrderBy(l => l.DataHora)
            .ToList();

        string formatoGrupo = agrupamento switch
        {
            "minuto" => "dd/MM HH:mm",
            "dia" => "dd/MM/yyyy",
            _ => "dd/MM HH'h'"
        };
        var grupos = leituras.GroupBy(l => l.DataHora.ToString(formatoGrupo)).ToList();

        return new DashboardViewModel
        {
            ValoresAtuais = dispositivo.Atributos
                .Select(a => new LeituraAtualViewModel(a.Nome, atuais.GetValueOrDefault(a.Nome, "—")))
                .ToList(),
            AtualizadoEm = DateTimeOffset.TryParse(atuais.GetValueOrDefault("TimeInstant"), out var instante)
                ? instante.LocalDateTime.ToString("dd/MM/yyyy HH:mm:ss")
                : null,

            Rotulos = leituras.Select(l => l.DataHora.ToString("dd/MM HH:mm:ss")).ToList(),
            Valores = leituras.Select(l => l.Valor).ToList(),

            RotulosAgrupados = grupos.Select(g => g.Key).ToList(),
            Minimos = grupos.Select(g => g.Min(l => l.Valor)).ToList(),
            Medias = grupos.Select(g => Math.Round(g.Average(l => l.Valor), 2)).ToList(),
            Maximos = grupos.Select(g => g.Max(l => l.Valor)).ToList(),

            TotalLeituras = leituras.Count,
            Minimo = leituras.Count > 0 ? leituras.Min(l => l.Valor) : null,
            Media = leituras.Count > 0 ? Math.Round(leituras.Average(l => l.Valor), 2) : null,
            Maximo = leituras.Count > 0 ? leituras.Max(l => l.Valor) : null
        };
    }
}
