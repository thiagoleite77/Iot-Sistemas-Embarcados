namespace DataLoggerWeb.DAO;

/// <summary>
/// Erro ao acessar o FIWARE (API fora do ar, timeout ou resposta de erro).
/// </summary>
public class FiwareException(string mensagem, int? statusCode = null) : Exception(mensagem)
{
    public int? StatusCode { get; } = statusCode;
}
