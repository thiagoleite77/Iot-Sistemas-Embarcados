using System.Text.Json.Nodes;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// CRUD de assinaturas (subscriptions) no Orion (/v2/subscriptions).
/// É a assinatura que faz o Orion enviar cada nova leitura para o STH-Comet (histórico).
/// </summary>
public class AssinaturaDAO : PadraoDAO<AssinaturaViewModel>
{
    /// <summary>
    /// Formato usado para o STH-Comet. O STH-Comet só entende notificações NGSIv1 e o Orion 4.x
    /// não gera mais esse formato ("attrsFormat": "legacy"). Por isso o corpo da notificação é
    /// montado com "httpCustom", com UMA assinatura por atributo (como no FIWARE Made Simple).
    /// </summary>
    public const string FormatoSth = "sth";

    protected override string Url => $"{HelperFiware.UrlOrion}/v2/subscriptions";

    protected override AssinaturaViewModel MontaModel(JsonNode registro)
    {
        var entidade = registro["subject"].Lista("entities").FirstOrDefault();
        var notificacao = registro["notification"];
        var httpCustom = notificacao?["httpCustom"];

        // Nas assinaturas do STH-Comet, o atributo e o tipo ficam dentro do corpo NGSIv1:
        // httpCustom.json.contextResponses[0].contextElement.attributes[0]
        var atributoSth = ((httpCustom?["json"]).Lista("contextResponses").FirstOrDefault()?["contextElement"])
            .Lista("attributes").FirstOrDefault();

        return new()
        {
            Id = registro.Texto("id"),
            Descricao = registro.Texto("description"),
            Status = registro.Texto("status"),
            EntidadeId = entidade.Texto("id") is { Length: > 0 } id ? id : entidade.Texto("idPattern"),
            EntidadeTipo = entidade.Texto("type"),
            AtributosCondicao = string.Join(", ", (registro["subject"]?["condition"]).Lista("attrs").Select(a => a.ToString())),
            AtributosNotificacao = string.Join(", ", notificacao.Lista("attrs").Select(a => a.ToString())),
            UrlNotificacao = (notificacao?["http"] ?? httpCustom).Texto("url"),
            Formato = atributoSth != null ? FormatoSth
                : notificacao.Texto("attrsFormat") is { Length: > 0 } formato ? formato
                : "normalized",
            TipoAtributo = atributoSth.Texto("type") is { Length: > 0 } tipo ? tipo : "Float",
            Throttling = (int)registro.Numero("throttling"),
            VezesEnviada = notificacao.Numero("timesSent"),
            UltimaNotificacao = notificacao.DataHora("lastNotification")
        };
    }

    protected override JsonObject CriaJson(AssinaturaViewModel model)
    {
        // ".*" (ou qualquer padrão com *) vira idPattern para assinar várias entidades
        var entidade = new JsonObject { ["type"] = model.EntidadeTipo };
        entidade[model.EntidadeId.Contains('*') ? "idPattern" : "id"] = model.EntidadeId;

        var atributos = HelperFiware.SeparaLista(model.AtributosNotificacao);

        var json = new JsonObject
        {
            ["description"] = model.Descricao,
            ["status"] = model.Status,
            ["subject"] = new JsonObject
            {
                ["entities"] = new JsonArray(entidade),
                ["condition"] = new JsonObject { ["attrs"] = HelperFiware.ParaJsonArray(HelperFiware.SeparaLista(model.AtributosCondicao)) }
            },
            ["notification"] = model.Formato == FormatoSth
                ? CriaNotificacaoSth(model.UrlNotificacao, atributos[0], model.TipoAtributo)
                : new JsonObject
                {
                    ["http"] = new JsonObject { ["url"] = model.UrlNotificacao },
                    ["attrs"] = HelperFiware.ParaJsonArray(atributos),
                    ["attrsFormat"] = model.Formato
                }
        };

        if (model.Throttling > 0)
            json["throttling"] = model.Throttling;

        return json;
    }

    /// <summary>
    /// Notificação no formato NGSIv1 esperado pelo STH-Comet. A cada mudança, o Orion troca
    /// ${id}, ${type} e ${atributo} pelos valores reais; como o ${atributo} ocupa o valor
    /// inteiro, o número chega ao histórico como número.
    /// </summary>
    private static JsonObject CriaNotificacaoSth(string url, string atributo, string tipo) => new()
    {
        ["httpCustom"] = new JsonObject
        {
            ["url"] = url,
            ["json"] = new JsonObject
            {
                ["contextResponses"] = new JsonArray(new JsonObject
                {
                    ["contextElement"] = new JsonObject
                    {
                        ["id"] = "${id}",
                        ["type"] = "${type}",
                        ["isPattern"] = "false",
                        ["attributes"] = new JsonArray(new JsonObject
                        {
                            ["name"] = atributo,
                            ["type"] = tipo,
                            ["value"] = "${" + atributo + "}"
                        })
                    },
                    ["statusCode"] = new JsonObject { ["code"] = "200", ["reasonPhrase"] = "OK" }
                })
            }
        },
        ["attrs"] = HelperFiware.ParaJsonArray([atributo])
    };

    public override Task UpdateAsync(AssinaturaViewModel model) =>
        HelperFiware.PatchAsync(UrlRegistro(model.Id), CriaJson(model));

    /// <summary>Assinatura do STH-Comet pré-preenchida para um atributo do dispositivo.</summary>
    public static AssinaturaViewModel NovaAssinaturaHistorico(DispositivoViewModel? dispositivo = null, AtributoViewModel? atributo = null) => new()
    {
        Descricao = dispositivo == null || atributo == null
            ? string.Empty
            : $"Histórico STH-Comet - {dispositivo.Id} - {atributo.Nome}",
        EntidadeId = dispositivo?.EntityName ?? string.Empty,
        EntidadeTipo = dispositivo?.EntityType ?? string.Empty,
        AtributosCondicao = atributo?.Nome,
        AtributosNotificacao = atributo?.Nome,
        TipoAtributo = atributo?.Tipo ?? "Float",
        UrlNotificacao = $"{HelperFiware.Config.UrlSthInterna}/notify",
        Formato = FormatoSth,
        Status = "active"
    };

    /// <summary>
    /// Cria uma assinatura do STH-Comet para cada atributo do dispositivo, pulando as que já existem.
    /// Assinatura repetida faria cada leitura ser gravada duas vezes no histórico (distorce as médias).
    /// </summary>
    /// <returns>Quantas foram criadas e quantas já existiam.</returns>
    public async Task<(int Criadas, int Existentes)> CriaAssinaturasHistoricoAsync(DispositivoViewModel dispositivo)
    {
        var atributosComAssinatura = (await ListagemAsync())
            .Where(a => a.Formato == FormatoSth && a.EntidadeId == dispositivo.EntityName)
            .Select(a => a.AtributosNotificacao)
            .ToHashSet();

        int criadas = 0;
        foreach (var atributo in dispositivo.Atributos.Where(a => !atributosComAssinatura.Contains(a.Nome)))
        {
            await InsertAsync(NovaAssinaturaHistorico(dispositivo, atributo));
            criadas++;
        }

        return (criadas, dispositivo.Atributos.Count - criadas);
    }
}
