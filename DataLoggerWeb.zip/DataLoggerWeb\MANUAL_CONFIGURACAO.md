# Data Logger IoT – Configuração dos dispositivos pelo site

Passo a passo para quem recebe **só o front-end** (este site) e precisa deixar o data logger funcionando.
Este guia parte do princípio de que o **FIWARE já está instalado na EC2** do AWS Learner Lab (repositório [FIWARE Made Simple](https://github.com/fabiocabrini/fiware-made-simple)).

---

## Antes de começar

| Você precisa de | Observação |
|---|---|
| Visual Studio 2022 com o SDK do **.NET 8** | Para abrir e executar o site |
| A pasta do projeto `DataLoggerWeb` (ZIP extraído) | Não precisa instalar mais nada: o pacote da AWS é baixado na primeira execução |
| Acesso ao **AWS Learner Lab** da equipe | Para ligar o lab e copiar as credenciais |
| O **nome** (ou o Id) da instância EC2 | Ex.: `fiware` |
| Os valores combinados com quem programou o ESP32 | Tabela abaixo |

### Valores que precisam ser IGUAIS no ESP32 e no site

Diferenciam maiúsculas de minúsculas e não aceitam espaços nem acentos.

| Item | Exemplo | No ESP32 (firmware) | No site |
|---|---|---|---|
| API Key | `TEF` | `APIKEY` | Service Groups → **API Key** |
| Device ID | `datalogger001` | `DEVICE_ID` | Dispositivos → **Device ID** |
| Chave da temperatura | `t` | Usada no payload | Atributo `temperatura` → **object_id** |
| Chave da umidade | `h` | Usada no payload | Atributo `umidade` → **object_id** |
| Chave da luminosidade | `l` | Usada no payload | Atributo `luminosidade` → **object_id** |
| Comandos (se houver) | `ledon`, `ledoff` | Tratados no tópico `/cmd` | Dispositivos → **Comandos** |
| Endereço do broker | IP público da EC2 | `MQTT_BROKER` | Aparece no card da AWS na tela **Início** |

---

## Passo 1 – Abrir o projeto
1. Extraia o ZIP em uma pasta que você consiga editar.
2. Dê dois cliques em `DataLoggerWeb.csproj` para abrir no Visual Studio.

## Passo 2 – Apontar o site para a sua EC2
1. Abra o arquivo `appsettings.json`.
2. Na seção `"Aws"`, coloque em `"NomeInstancia"` o nome da EC2 (como aparece no console da AWS). Se preferir, preencha `"InstanciaId"` com o Id da instância (ex.: `i-0abc1234def567890`).
3. Não mexa na seção `"Fiware"`, a não ser que a equipe tenha usado outro `fiware-service`. O padrão é `smart` e `/`.
4. Salve o arquivo.

## Passo 3 – Colar as credenciais do Learner Lab
1. No Learner Lab, clique em **Start Lab** e espere o indicador ficar **verde**.
2. Clique em **AWS Details → AWS CLI → Show** e copie o bloco inteiro (começa com `[default]`).
3. No Visual Studio, abra o arquivo **`.aws/credentials`** do projeto, apague tudo, cole o bloco e salve.

> As credenciais mudam a cada Start Lab. Repita este passo em toda sessão. Nunca envie esse arquivo para o GitHub.

## Passo 4 – Executar e conferir a conexão
1. Pressione **F5**. O site abre na tela **Início**.
2. Espere o card **AWS Learner Lab · IP automático** mostrar o **IP público**. Se a EC2 estiver desligada, o site liga e espera; isso leva cerca de 1 minuto.
3. Confira se **Orion Context Broker**, **IoT Agent MQTT** e **STH-Comet** aparecem como **Online**. Logo depois que a EC2 liga, clique em **Verificar novamente** após alguns segundos.

## Passo 5 – Criar o Service Group (uma vez só)
1. Menu **Service Groups → Novo service group**.
2. Preencha:
   - **API Key:** a mesma do firmware (ex.: `TEF`).
   - **Resource:** deixe vazio.
   - **Tipo padrão das entidades:** `DataLogger`.
   - **URL do Context Broker:** mantenha `http://orion:1026`.
3. Clique em **Salvar no FIWARE**.

## Passo 6 – Cadastrar o dispositivo (uma vez só)
1. Menu **Dispositivos → Novo dispositivo**.
2. Preencha a identificação:
   - **Device ID:** o mesmo do firmware (ex.: `datalogger001`).
   - **Nome da entidade no Orion:** `urn:ngsi-ld:DataLogger:001`.
   - **Tipo da entidade:** `DataLogger`.
   - **API Key (Service Group):** a mesma do firmware (ex.: `TEF`). O site já sugere a do Service Group cadastrado. **Sem ela, o IoT Agent não reconhece as mensagens do ESP32.**
   - **Protocolo:** UltraLight 2.0. **Transporte:** MQTT.
3. Confira os **atributos**. A tela já vem com os três do data logger:

   | object_id | Nome do atributo | Tipo |
   |---|---|---|
   | `t` | `temperatura` | Float |
   | `h` | `umidade` | Float |
   | `l` | `luminosidade` | Integer |

   Ajuste os `object_id` se o firmware usar outras letras.
4. Em **Comandos**, preencha só se o firmware tratar comandos, separados por vírgula. Se não, deixe vazio.
5. Deixe marcada a opção **Criar assinatura no Orion para gravar o histórico no STH-Comet**.
6. Clique em **Salvar no FIWARE**. A mensagem deve dizer **"3 assinatura(s) do STH-Comet criada(s)"**.

## Passo 7 – Conferir as assinaturas do histórico
1. Menu **Assinaturas**: devem aparecer **3 linhas** (temperatura, umidade e luminosidade) com o selo **STH-Comet**.
2. Se faltar alguma, volte em **Dispositivos** e clique no botão do **sino** do dispositivo. Ele cria só as que faltam, sem duplicar.

> Não crie assinaturas repetidas à mão: cada leitura seria gravada duas vezes e as médias ficariam erradas.

## Passo 8 – Passar os dados para o ESP32
1. Em **Dispositivos**, clique no ícone de **olho** (Detalhes) do dispositivo.
2. Envie para quem programa o ESP32:
   - O **tópico MQTT** e o **exemplo de payload** mostrados no card "Integração com o firmware".
   - O **IP público** que aparece no card da AWS na tela **Início**. Esse IP muda a cada sessão do Learner Lab.

## Passo 9 – Ligar o ESP32 e validar
1. Ligue o ESP32 e espere cerca de 30 segundos.
2. Em **Detalhes do dispositivo**, clique em **Atualizar**: os **valores atuais** devem aparecer no lugar de "—".
3. Em **Assinaturas**, a coluna **Notificações** deve aumentar a cada leitura.
4. Abra a **Consulta IoT** (clique em Pesquisar) e o **Dashboard**: as leituras e os gráficos devem aparecer.
5. Para testar o alerta à mão, ainda em **Detalhes do dispositivo**, escolha um valor no comando **`alerta`** e clique em **Enviar**. O índice da tela mostra o que cada valor sinaliza (0 = normal, 1 = temperatura, 2 = umidade, 3 = luminosidade). Envie **0** para desligar.
6. Para o alerta **automático**, deixe o **Dashboard aberto** com a chave **"Enviar o alerta ao ESP32 automaticamente"** ligada. Ele envia o código quando uma grandeza sai do limite e envia **0** quando tudo volta ao normal. A linha ao lado da chave mostra o último envio.
7. **Na apresentação**, use o botão **Testar alerta** de cada grandeza no painel. Ele grava leituras fora do limite (`ValorTeste`), o painel entra em alerta e o ESP32 pisca e apita. Com o ESP32 ligado, o alerta volta ao normal sozinho em cerca de 30–40 s. Para esconder os botões depois, use `"BotoesTeste": false` no `appsettings.json`.

## Passo 10 – (Opcional) Ajustar os limites dos alertas
1. No `appsettings.json`, seção `"Alertas"`, ajuste `Minimo`, `Maximo` e `Prioridade` de cada grandeza. Os valores que vêm no projeto são só exemplos.
2. Não altere `CodigoAlerta` e `CodigoNormal`, a não ser que o firmware mude: eles precisam ser iguais aos códigos tratados no ESP32.
3. Pare e execute o site de novo (F5) para aplicar.

---

## A cada nova sessão do Learner Lab
1. **Start Lab** e espere ficar verde.
2. Copie as novas credenciais para `.aws/credentials` (Passo 3).
3. Execute o site (F5), ou clique em **Atualizar IP pela AWS** na tela **Início** se ele já estiver aberto.
4. Passe o **novo IP** para o ESP32 (`MQTT_BROKER`).

Service Group, dispositivo e assinaturas **continuam salvos** no FIWARE: não precisa cadastrar de novo.

---

## Problemas comuns

| O que aparece | Causa provável | O que fazer |
|---|---|---|
| Card da AWS: "Credenciais ... não encontradas" ou "vencidas" | Arquivo `.aws/credentials` vazio ou de uma sessão anterior | Refaça o Passo 3 e clique em **Atualizar IP pela AWS** |
| Card da AWS: "Nenhuma instância encontrada" | Nome ou Id da EC2 diferente do `appsettings.json` | Corrija o Passo 2 e execute de novo |
| Componentes **Offline** com o IP já encontrado | A EC2 acabou de ligar, os containers não subiram ou as portas estão fechadas | Espere e clique em **Verificar novamente**. Se continuar, confira o Security Group (1026, 4041, 8666) |
| "Já existe um registro com este identificador" | O Service Group ou o dispositivo já foi cadastrado | Use o que já existe (ou exclua e cadastre de novo) |
| Valores atuais continuam "—" | O ESP32 não está publicando ou os nomes não batem | Confira API Key, Device ID, `object_id`, IP e a porta 1883 aberta. O "PUB" no serial não garante o envio: veja se o LCD mostra `!MQ` |
| Selo **sem API Key** no dispositivo | Dispositivo cadastrado antes desta versão (ou fora do site) | Clique em **Alterar**, escolha a API Key e salve |
| Aparece outro dispositivo com o mesmo ID (entidade `DataLogger:env001` ou `Thing:env001`) | O IoT Agent criou um dispositivo novo porque não reconheceu o seu | Exclua o duplicado e corrija a API Key do original |
| Service Group com autoprovisionamento **Ligado** | Grupo criado antes desta versão (ou pelo Postman sem `autoprovision`) | Clique em **Alterar** e salve: o site desliga o autoprovisionamento |
| Consulta IoT vazia, mas os valores atuais mudam | Faltam as assinaturas do histórico | Clique no **sino** do dispositivo (Passo 7) |
| "A quantidade deve estar entre 1 e 100" | O STH-Comet devolve no máximo 100 leituras por consulta | Use um número até 100 |

---

## Anexo – O que o ESP32 precisa ter

Para a equipe do firmware. Os nomes seguem o exemplo oficial do repositório (`examples/esp32-smart-lamp`).

### Hardware (do kickoff do projeto)
| Componente | Ligação sugerida | Observação |
|---|---|---|
| ESP32 DevKit V1 | — | Wi-Fi 2,4 GHz |
| DHT11 (temperatura e umidade) | Dados no **GPIO 4** | Ler no máximo a cada 2 s; descartar leituras inválidas (NaN) |
| LDR (luminosidade) | `AO` no **GPIO 34** | Use um pino ADC1 (32 a 39): os pinos ADC2 não funcionam com o Wi-Fi ligado. Converter 0–4095 para 0–100 % |
| LED azul | **GPIO 2** (LED da placa) ou outro pino com resistor | Alerta visual |
| Buzzer (passivo) | Ex.: **GPIO 25** | Frequências diferentes por grandeza (`ledcWriteTone`) |

### Bibliotecas
`WiFi.h` (já vem com o ESP32), **PubSubClient** (Nick O'Leary) e **DHT sensor library** (Adafruit), com a **Adafruit Unified Sensor**.

### Constantes do firmware
| Constante | Valor |
|---|---|
| `WIFI_SSID` / `WIFI_PASSWORD` | Rede Wi-Fi do local da apresentação |
| `MQTT_BROKER` | IP público da EC2 (muda a cada sessão) |
| `MQTT_PORT` | `1883` |
| `APIKEY` | Igual ao Service Group (ex.: `TEF`) |
| `DEVICE_ID` | Igual ao dispositivo (ex.: `datalogger001`) |

### Tópicos MQTT (UltraLight 2.0)
| Direção | Tópico | Mensagem |
|---|---|---|
| Publica | `/<APIKEY>/<DEVICE_ID>/attrs` | `t\|25.4\|h\|61\|l\|72` |
| Assina | `/<APIKEY>/<DEVICE_ID>/cmd` | `<DEVICE_ID>@<comando>\|` |
| Publica | `/<APIKEY>/<DEVICE_ID>/cmdexe` | `<DEVICE_ID>@<comando>\|ok` (confirmação obrigatória) |

### Regras
- Use **ponto** como separador decimal (`25.4`, nunca `25,4`) e não coloque unidades no payload.
- Publique a cada **5 a 10 segundos**.
- Use um **Client ID MQTT único** (ex.: `DEVICE_ID` + parte do MAC): dois aparelhos com o mesmo ID derrubam um ao outro.
- Reconecte sozinho ao Wi-Fi e ao broker se a conexão cair, e chame `mqtt.loop()` em todo ciclo do `loop()`.
- O site envia o comando com o valor escolhido: o ESP32 recebe `<DEVICE_ID>@<comando>|<valor>` (ex.: `env001@alerta|1`) e deve sempre confirmar no `/cmdexe`.
- Os códigos do comando `alerta` (0 = normal, 1 = temperatura, 2 = umidade, 3 = luminosidade) precisam ser iguais aos do `appsettings.json` do site (`CodigoNormal` e `CodigoAlerta`).
- O ESP32 **não** compara as leituras com limites: o alerta só liga ou desliga quando chega um comando. Quem envia é o **Dashboard do site** (automático, com a página aberta) ou a tela Detalhes (manual).
