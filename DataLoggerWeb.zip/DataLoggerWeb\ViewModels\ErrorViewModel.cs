namespace DataLoggerWeb.ViewModels;

public class ErrorViewModel
{
    public ErrorViewModel() { }

    public ErrorViewModel(string erro) => Erro = erro;

    public string Erro { get; set; } = string.Empty;
    public string? RequestId { get; set; }
}
