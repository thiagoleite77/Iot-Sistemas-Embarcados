namespace DataLoggerWeb.DAO;

/// <summary>
/// Configurações da descoberta automática do IP da EC2 (seção "Aws" do appsettings.json).
/// As credenciais NÃO ficam aqui: são lidas do arquivo indicado em ArquivoCredenciais.
/// </summary>
public class AwsConfig
{
    /// <summary>
    /// Arquivo com as credenciais copiadas do Learner Lab. Caminho relativo à pasta do
    /// projeto (ou absoluto). Padrão: pasta .aws dentro do próprio projeto.
    /// </summary>
    public string ArquivoCredenciais { get; set; } = ".aws/credentials";

    /// <summary>false = não consulta a AWS e usa o Host fixo da seção "Fiware".</summary>
    public bool Habilitado { get; set; } = true;

    /// <summary>Região da instância (o Learner Lab usa us-east-1).</summary>
    public string Regiao { get; set; } = "us-east-1";

    /// <summary>Perfil do arquivo de credenciais (o bloco copiado do Learner Lab é o [default]).</summary>
    public string Perfil { get; set; } = "default";

    /// <summary>Id da instância (ex.: i-0abc1234def567890). Se vazio, procura pela tag Name.</summary>
    public string? InstanciaId { get; set; }

    /// <summary>Valor da tag Name da instância (o nome dado ao criar a EC2).</summary>
    public string? NomeInstancia { get; set; } = "fiware";

    /// <summary>Liga a instância automaticamente se ela estiver desligada.</summary>
    public bool LigarInstancia { get; set; } = true;

    /// <summary>Tempo máximo esperando a instância ligar e receber o IP público.</summary>
    public int TempoEsperaSegundos { get; set; } = 180;
}
