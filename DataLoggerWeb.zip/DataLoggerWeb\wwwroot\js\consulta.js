// Consulta de mensagens IoT via Ajax
$(function () {
    const $form = $('#formConsulta');
    const $resultado = $('#resultadoConsulta');
    const selectDispositivo = document.getElementById('DispositivoId');
    const selectAtributo = document.getElementById('Atributo');

    if (!selectDispositivo)
        return; // nenhum dispositivo cadastrado

    $(selectDispositivo).on('change', function () {
        HelperUI.preencheAtributos(selectDispositivo, selectAtributo, true);
    }).trigger('change');

    $form.on('submit', function (evento) {
        evento.preventDefault();
        pesquisa();
    });

    $('#btnExportar').on('click', function () {
        HelperUI.exportaCsv('tabelaMensagens', 'mensagens-iot.csv');
    });

    function pesquisa() {
        $resultado.html(HelperUI.spinner);

        $.ajax({
            url: $form.data('url'),
            data: $form.serialize(),
            cache: false,
            success: function (dados) {
                // O controller devolve JSON quando há erro e HTML (partial) quando dá certo
                if (dados.erro)
                    HelperUI.mostraErro($resultado, dados.msg);
                else
                    $resultado.html(dados);
            },
            error: function () {
                HelperUI.mostraErro($resultado, 'Falha na comunicação com o servidor.');
            }
        });
    }
});
