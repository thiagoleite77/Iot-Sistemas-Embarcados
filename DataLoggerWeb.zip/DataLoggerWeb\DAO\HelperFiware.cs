using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Centraliza as chamadas HTTP às APIs do FIWARE (Orion, IoT Agent e STH-Comet).
/// Faz o papel que o HelperDAO faz com o banco: todos os DAOs passam por aqui.
/// </summary>
public static class HelperFiware
{
    // Um único HttpClient para toda a aplicação (evita esgotar as portas/sockets)
    private static readonly HttpClient cliente = new();

    public static FiwareConfig Config { get; private set; } = new();

    public static string UrlOrion => $"http://{Config.Host}:{Config.PortaOrion}";
    public static string UrlIoTAgent => $"http://{Config.Host}:{Config.PortaIoTAgent}";
    public static string UrlSth => $"http://{Config.Host}:{Config.PortaSth}";

    public static void Configura(FiwareConfig config) => Config = config;

    /// <summary>Troca o endereço do FIWARE com o site rodando (usado pela descoberta do IP na AWS).</summary>
    public static void AlteraHost(string host) => Config.Host = host;

    public static Task<JsonNode?> GetAsync(string url, bool nullSeNaoEncontrado = false) =>
        EnviaAsync(HttpMethod.Get, url, null, nullSeNaoEncontrado);

    public static Task<JsonNode?> PostAsync(string url, JsonNode corpo) => EnviaAsync(HttpMethod.Post, url, corpo);

    public static Task<JsonNode?> PutAsync(string url, JsonNode corpo) => EnviaAsync(HttpMethod.Put, url, corpo);

    public static Task<JsonNode?> PatchAsync(string url, JsonNode corpo) => EnviaAsync(HttpMethod.Patch, url, corpo);

    public static Task<JsonNode?> DeleteAsync(string url, bool ignoraNaoEncontrado = false) =>
        EnviaAsync(HttpMethod.Delete, url, null, ignoraNaoEncontrado);

    private static async Task<JsonNode?> EnviaAsync(HttpMethod metodo, string url, JsonNode? corpo, bool nullSeNaoEncontrado = false)
    {
        using var requisicao = new HttpRequestMessage(metodo, url);
        requisicao.Headers.Add("fiware-service", Config.FiwareService);
        requisicao.Headers.Add("fiware-servicepath", Config.FiwareServicePath);
        requisicao.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        if (corpo != null)
        {
            requisicao.Content = new StringContent(corpo.ToJsonString());
            // O Orion exige exatamente "application/json" (sem charset)
            requisicao.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        }

        using var tempoLimite = new CancellationTokenSource(TimeSpan.FromSeconds(Config.TimeoutSegundos));
        try
        {
            using var resposta = await cliente.SendAsync(requisicao, tempoLimite.Token);
            string conteudo = await resposta.Content.ReadAsStringAsync(tempoLimite.Token);

            if (resposta.StatusCode == HttpStatusCode.NotFound && nullSeNaoEncontrado)
                return null;

            if (!resposta.IsSuccessStatusCode)
                throw new FiwareException(MontaMensagemErro(resposta.StatusCode, conteudo), (int)resposta.StatusCode);

            return string.IsNullOrWhiteSpace(conteudo) ? null : JsonNode.Parse(conteudo);
        }
        catch (OperationCanceledException)
        {
            throw new FiwareException($"Tempo esgotado ({Config.TimeoutSegundos}s) ao acessar {url}. Verifique se o FIWARE está em execução.");
        }
        catch (HttpRequestException erro)
        {
            throw new FiwareException($"Não foi possível conectar ao FIWARE em {url}. Confira o IP e as portas no appsettings.json. ({erro.Message})");
        }
        catch (JsonException)
        {
            throw new FiwareException($"A resposta de {url} não é um JSON válido. Confira se a porta configurada é a do componente correto.");
        }
    }

    /// <summary>
    /// Cada componente do FIWARE devolve o erro num formato diferente:
    /// Orion {error, description} | IoT Agent {name, message} | STH {error, message}
    /// </summary>
    private static string MontaMensagemErro(HttpStatusCode status, string conteudo)
    {
        string detalhe = conteudo;
        try
        {
            var json = JsonNode.Parse(conteudo) as JsonObject;
            detalhe = (json?["description"] ?? json?["message"] ?? json?["error"] ?? json?["name"])?.ToString() ?? conteudo;
        }
        catch (JsonException)
        {
            // corpo não é JSON: usa o texto puro
        }
        return $"O FIWARE recusou a operação ({(int)status} - {status}): {detalhe}";
    }

    // ------------------------------------------------------------------
    // Métodos de extensão para ler o JSON devolvido pelas APIs
    // ------------------------------------------------------------------

    /// <summary>Lê uma propriedade como texto ("" se não existir).</summary>
    public static string Texto(this JsonNode? no, string propriedade) =>
        (no as JsonObject)?[propriedade]?.ToString() ?? string.Empty;

    /// <summary>Lê uma propriedade do tipo array (lista vazia se não existir).</summary>
    public static IEnumerable<JsonNode> Lista(this JsonNode? no, string propriedade) =>
        ((no as JsonObject)?[propriedade] as JsonArray)?.OfType<JsonNode>() ?? [];

    /// <summary>Lê uma data ISO 8601 (UTC) e converte para o horário local.</summary>
    public static DateTime? DataHora(this JsonNode? no, string propriedade) =>
        DateTimeOffset.TryParse(no.Texto(propriedade), CultureInfo.InvariantCulture, DateTimeStyles.None, out var data)
            ? data.LocalDateTime
            : null;

    public static long Numero(this JsonNode? no, string propriedade) =>
        long.TryParse(no.Texto(propriedade), out long numero) ? numero : 0;

    /// <summary>"a, b ,c" => ["a", "b", "c"]</summary>
    public static List<string> SeparaLista(string? texto) =>
        texto?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct().ToList() ?? [];

    public static JsonArray ParaJsonArray(IEnumerable<string> itens) =>
        new(itens.Select(item => (JsonNode?)JsonValue.Create(item)).ToArray());

    /// <summary>Formata a data no padrão aceito pelo STH-Comet (UTC).</summary>
    public static string FormataDataIso(DateTime data) =>
        data.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'", CultureInfo.InvariantCulture);
}
