namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Situação de um componente do FIWARE (Orion, IoT Agent ou STH-Comet).
/// </summary>
public class FiwareStatusViewModel
{
    public string Componente { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;
    public bool Online { get; set; }
    public string? Versao { get; set; }
    public string? Mensagem { get; set; }
}
