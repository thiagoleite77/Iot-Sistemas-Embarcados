// Funções utilitárias compartilhadas por todas as telas
const HelperUI = {
    spinner: '<div class="text-center p-4"><div class="spinner-border text-primary" role="status"></div>' +
             '<p class="mt-2 mb-0 text-muted">Consultando o FIWARE...</p></div>',

    // Mostra um alerta de erro (usa .text() para não interpretar HTML vindo do servidor)
    mostraErro: function ($container, mensagem) {
        $container.empty().append(
            $('<div class="alert alert-danger mb-0"></div>').text(mensagem));
    },

    mostraAviso: function ($container, mensagem) {
        $container.empty().append(
            $('<div class="alert alert-info"></div>').text(mensagem));
    },

    // Preenche o <select> de atributos com base no data-atributos do dispositivo escolhido
    preencheAtributos: function (selectDispositivo, selectAtributo, incluiTodos) {
        const opcao = selectDispositivo.selectedOptions[0];
        const atributos = opcao && opcao.dataset.atributos ? opcao.dataset.atributos.split(',') : [];

        selectAtributo.innerHTML = '';
        if (incluiTodos)
            selectAtributo.add(new Option('Todos', ''));
        atributos.forEach(a => selectAtributo.add(new Option(a, a)));
    },

    // Exporta uma tabela HTML para CSV (separador ; para abrir direto no Excel)
    exportaCsv: function (idTabela, nomeArquivo) {
        const linhas = [...document.querySelectorAll('#' + idTabela + ' tr')].map(tr =>
            [...tr.children].map(celula => '"' + celula.innerText.replace(/"/g, '""') + '"').join(';'));

        if (linhas.length <= 1) {
            alert('Faça uma consulta com resultados antes de exportar.');
            return;
        }

        const arquivo = new Blob(['﻿' + linhas.join('\r\n')], { type: 'text/csv;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(arquivo);
        link.download = nomeArquivo;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    }
};

// Filtro rápido de tabelas: <input data-filtro-tabela="idDaTabela">
$(document).on('input', '[data-filtro-tabela]', function () {
    const termo = this.value.toLowerCase();
    $('#' + $(this).data('filtro-tabela') + ' tbody tr').each(function () {
        $(this).toggle($(this).text().toLowerCase().includes(termo));
    });
});

// Confirmação antes de excluir: <form data-confirmacao="mensagem">
$(document).on('submit', 'form[data-confirmacao]', function () {
    return confirm($(this).data('confirmacao'));
});
