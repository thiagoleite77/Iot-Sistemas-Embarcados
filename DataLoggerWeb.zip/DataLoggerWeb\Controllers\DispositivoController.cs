using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

public class DispositivoController : PadraoController<DispositivoViewModel>
{
    private static readonly string[] NomesReservados = ["id", "type", "TimeInstant"];

    private readonly ServicoDAO servicoDAO = new();

    public DispositivoController() : base(new DispositivoDAO()) { }

    /// <summary>API Keys dos Service Groups para o campo "API Key" do formulário.</summary>
    protected override async Task PreencheDadosParaView(string operacao, DispositivoViewModel model)
    {
        var apiKeys = await ListaApiKeysAsync();
        ViewBag.ApiKeys = apiKeys;

        // Na inclusão, já sugere a primeira API Key cadastrada
        if (operacao == "I" && string.IsNullOrEmpty(model.Apikey) && apiKeys.Count > 0)
            model.Apikey = apiKeys[0];
    }

    private async Task<List<string>> ListaApiKeysAsync() =>
        (await servicoDAO.ListagemAsync()).Select(s => s.Id).ToList();

    /// <summary>Sugestão inicial de atributos para o data logger (podem ser alterados na tela).</summary>
    protected override DispositivoViewModel CriaModelPadrao() => new()
    {
        Atributos =
        [
            new() { ObjectId = "t", Nome = "temperatura", Tipo = "Float" },
            new() { ObjectId = "h", Nome = "umidade", Tipo = "Float" },
            new() { ObjectId = "l", Nome = "luminosidade", Tipo = "Integer" }
        ]
    };

    protected override async Task ValidaDados(DispositivoViewModel model, string operacao)
    {
        await base.ValidaDados(model, operacao);

        if (!HelperControllers.IdentificadorValido(model.EntityName))
            ModelState.AddModelError(nameof(model.EntityName), "Informe o nome da entidade (ex.: urn:ngsi-ld:DataLogger:001).");

        if (!HelperControllers.IdentificadorValido(model.EntityType))
            ModelState.AddModelError(nameof(model.EntityType), "Informe o tipo da entidade (ex.: DataLogger).");

        if (model.Protocolo is not ("PDI-IoTA-UltraLight" or "PDI-IoTA-JSON"))
            ModelState.AddModelError(nameof(model.Protocolo), "Protocolo inválido.");

        if (model.Transporte is not ("MQTT" or "HTTP"))
            ModelState.AddModelError(nameof(model.Transporte), "Transporte inválido.");

        // A API Key liga as mensagens MQTT (/apikey/device_id/attrs) a este dispositivo no IoT Agent
        var apiKeys = await ListaApiKeysAsync();
        if (apiKeys.Count == 0)
            ModelState.AddModelError(nameof(model.Apikey), "Cadastre um Service Group antes do dispositivo.");
        else if (string.IsNullOrWhiteSpace(model.Apikey) || !apiKeys.Contains(model.Apikey))
            ModelState.AddModelError(nameof(model.Apikey), "Escolha a API Key de um Service Group (a mesma usada no firmware).");

        ValidaAtributos(model);
        ValidaComandos(model);
    }

    private void ValidaAtributos(DispositivoViewModel model)
    {
        // Ignora as linhas que ficaram totalmente vazias na tabela
        model.Atributos = (model.Atributos ?? [])
            .Where(a => !string.IsNullOrWhiteSpace(a.ObjectId) || !string.IsNullOrWhiteSpace(a.Nome))
            .ToList();

        string? erro = null;
        if (model.Atributos.Count == 0)
            erro = "Informe ao menos um atributo.";
        else if (model.Atributos.Any(a => !HelperControllers.IdentificadorValido(a.ObjectId) || !HelperControllers.IdentificadorValido(a.Nome)))
            erro = "Todos os atributos precisam de object_id e nome válidos (sem espaços ou acentos).";
        else if (model.Atributos.Any(a => !AtributoViewModel.Tipos.Contains(a.Tipo)))
            erro = "Tipo de atributo inválido.";
        else if (model.Atributos.DistinctBy(a => a.Nome).Count() != model.Atributos.Count ||
                 model.Atributos.DistinctBy(a => a.ObjectId).Count() != model.Atributos.Count)
            erro = "Existem atributos com nome ou object_id repetidos.";
        else if (model.Atributos.Any(a => NomesReservados.Contains(a.Nome)))
            erro = "Os nomes id, type e TimeInstant são reservados pelo FIWARE.";

        if (erro != null)
            ModelState.AddModelError(nameof(model.Atributos), erro);
    }

    private void ValidaComandos(DispositivoViewModel model)
    {
        var comandos = HelperFiware.SeparaLista(model.Comandos);

        if (comandos.Any(c => !HelperControllers.IdentificadorValido(c)))
            ModelState.AddModelError(nameof(model.Comandos), "Nome de comando inválido (use letras, números e _).");
        else if (comandos.Intersect(model.Atributos.Select(a => a.Nome)).Any())
            ModelState.AddModelError(nameof(model.Comandos), "Um comando não pode ter o mesmo nome de um atributo.");
    }

    /// <summary>Na inclusão, cria as assinaturas (uma por atributo) que enviam as leituras ao STH-Comet.</summary>
    protected override async Task AposSalvar(DispositivoViewModel model, string operacao)
    {
        if (operacao != "I" || !model.CriarAssinaturaSth)
            return;

        try
        {
            var (criadas, _) = await new AssinaturaDAO().CriaAssinaturasHistoricoAsync(model);
            TempData["Sucesso"] = $"Dispositivo incluído e {criadas} assinatura(s) do STH-Comet criada(s), uma por atributo!";
        }
        catch (FiwareException erro)
        {
            TempData["Erro"] = $"Dispositivo incluído, mas não foi possível criar as assinaturas do STH-Comet: {erro.Message}";
        }
    }

    public async Task<IActionResult> Detalhes(string id)
    {
        try
        {
            var dispositivo = await DAO.ConsultaAsync(id);
            if (dispositivo == null)
            {
                TempData["Erro"] = $"Dispositivo '{id}' não encontrado.";
                return RedirectToAction(nameof(Index));
            }

            var valores = new EntidadeDAO().ConsultaValoresAtuaisAsync(dispositivo.EntityName, dispositivo.EntityType);
            var servicos = new ServicoDAO().ListagemAsync();

            ViewBag.ValoresAtuais = await valores;
            ViewBag.ApiKeys = (await servicos).Select(s => s.Id).ToList();

            // Índice do comando de alerta: só as grandezas que este dispositivo mede
            ViewBag.LimitesAlerta = AlertaDAO.Config.Limites
                .Where(l => dispositivo.Atributos.Any(a => a.Nome == l.Atributo))
                .OrderBy(l => l.CodigoAlerta)
                .ToList();
            return View(dispositivo);
        }
        catch (Exception erro)
        {
            return TrataErro(erro);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EnviarComando(string id, string comando, string? valor)
    {
        valor = valor?.Trim() ?? string.Empty;
        try
        {
            if (!HelperControllers.ValorComandoValido(valor))
                throw new FiwareException("Valor inválido: use só letras, números, ponto, hífen ou _ (até 50 caracteres).");

            var dispositivo = await DAO.ConsultaAsync(id) ?? throw new FiwareException($"Dispositivo '{id}' não encontrado.");

            if (!HelperFiware.SeparaLista(dispositivo.Comandos).Contains(comando))
                throw new FiwareException($"O comando '{comando}' não está cadastrado neste dispositivo.");

            await new EntidadeDAO().EnviaComandoAsync(dispositivo.EntityName, dispositivo.EntityType, comando, valor);
            TempData["Sucesso"] = $"Comando enviado: o ESP32 recebe {id}@{comando}|{valor}";
        }
        catch (Exception erro)
        {
            TempData["Erro"] = erro.Message;
        }
        return RedirectToAction(nameof(Detalhes), new { id });
    }
}
