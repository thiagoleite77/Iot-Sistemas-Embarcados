using System.Text.RegularExpressions;

namespace DataLoggerWeb.Controllers;

/// <summary>
/// Validações reaproveitadas pelos controllers.
/// </summary>
public static partial class HelperControllers
{
    // Identificadores aceitos pelo FIWARE: letras, números, _ - : . (sem espaços/acentos)
    [GeneratedRegex(@"^[A-Za-z0-9_\-:.]+$")]
    private static partial Regex RegexIdentificador();

    // Caracteres proibidos pelo Orion em textos: < > " ' = ; ( )
    [GeneratedRegex(@"[<>""'=;()]")]
    private static partial Regex RegexCaracteresProibidos();

    // Valor de comando: sem | e @, que são separadores do UltraLight (até 50 caracteres)
    [GeneratedRegex(@"^[A-Za-z0-9_.\-]{0,50}$")]
    private static partial Regex RegexValorComando();

    public static bool ValorComandoValido(string? texto) => RegexValorComando().IsMatch(texto ?? string.Empty);

    public static bool IdentificadorValido(string? texto) =>
        !string.IsNullOrWhiteSpace(texto) && texto.Length <= 256 && RegexIdentificador().IsMatch(texto);

    public static bool TextoValido(string? texto) =>
        !string.IsNullOrWhiteSpace(texto) && !RegexCaracteresProibidos().IsMatch(texto);

    public static bool UrlValida(string? texto) =>
        Uri.TryCreate(texto, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";
}
