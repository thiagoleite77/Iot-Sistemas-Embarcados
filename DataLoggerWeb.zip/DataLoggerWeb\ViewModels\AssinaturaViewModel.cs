namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Assinatura (subscription) do Orion. O Id é gerado pelo próprio Orion.
/// </summary>
public class AssinaturaViewModel : PadraoViewModel
{
    public string Descricao { get; set; } = string.Empty;
    public string EntidadeId { get; set; } = string.Empty;
    public string EntidadeTipo { get; set; } = string.Empty;

    /// <summary>Atributos que disparam a notificação (vazio = qualquer atributo).</summary>
    public string? AtributosCondicao { get; set; }

    /// <summary>Atributos enviados na notificação (vazio = todos).</summary>
    public string? AtributosNotificacao { get; set; }

    public string UrlNotificacao { get; set; } = string.Empty;

    /// <summary>"sth" (histórico no STH-Comet), "normalized" ou "keyValues".</summary>
    public string Formato { get; set; } = "sth";

    /// <summary>Tipo do atributo enviado ao STH-Comet (usado só no formato "sth").</summary>
    public string TipoAtributo { get; set; } = "Float";

    public string Status { get; set; } = "active";
    public int? Throttling { get; set; }

    // Somente leitura (informados pelo Orion)
    public long VezesEnviada { get; set; }
    public DateTime? UltimaNotificacao { get; set; }
}
