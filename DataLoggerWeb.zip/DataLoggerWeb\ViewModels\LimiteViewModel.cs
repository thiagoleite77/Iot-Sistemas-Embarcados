namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Faixa aceitável de uma grandeza (configurada no appsettings.json).
/// </summary>
public class LimiteViewModel
{
    /// <summary>Nome do atributo no Orion (ex.: "temperatura").</summary>
    public string Atributo { get; set; } = string.Empty;

    /// <summary>Nome exibido na tela (ex.: "Temperatura").</summary>
    public string Rotulo { get; set; } = string.Empty;

    public string Unidade { get; set; } = string.Empty;
    public double Minimo { get; set; }
    public double Maximo { get; set; }

    /// <summary>1 = mais importante. Usada quando mais de uma grandeza está fora do limite.</summary>
    public int Prioridade { get; set; }

    /// <summary>
    /// Valor enviado no comando de alerta para esta grandeza (ex.: env001@alerta|1).
    /// Precisa ser igual ao código tratado no firmware do ESP32.
    /// </summary>
    public int CodigoAlerta { get; set; }

    /// <summary>Valor fora da faixa gravado pelo botão "Testar alerta" do dashboard.</summary>
    public double ValorTeste { get; set; }

    /// <summary>Compara um valor com a faixa mínima e máxima.</summary>
    public string Classifica(double? valor) =>
        valor == null ? SituacaoAlerta.SemDados
        : valor < Minimo ? SituacaoAlerta.Abaixo
        : valor > Maximo ? SituacaoAlerta.Acima
        : SituacaoAlerta.Normal;
}
