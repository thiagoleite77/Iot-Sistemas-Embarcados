namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Dados da tela inicial (status do FIWARE e totais cadastrados).
/// Os totais ficam nulos quando o componente está fora do ar.
/// </summary>
public class HomeViewModel
{
    public List<FiwareStatusViewModel> Componentes { get; set; } = [];
    public AwsStatusViewModel Aws { get; set; } = new();
    public int? QtdDispositivos { get; set; }
    public int? QtdServicos { get; set; }
    public int? QtdAssinaturas { get; set; }
}
