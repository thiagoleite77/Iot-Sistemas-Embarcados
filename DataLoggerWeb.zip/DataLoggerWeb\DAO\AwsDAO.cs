using Amazon;
using Amazon.EC2;
using Amazon.EC2.Model;
using Amazon.Runtime;
using Amazon.Runtime.CredentialManagement;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Usa a API do EC2 (AWS SDK) para ligar a instância do FIWARE no Learner Lab
/// e descobrir o IP público dela. O IP encontrado passa a ser o Host do FIWARE.
/// </summary>
public class AwsDAO
{
    private static readonly TimeSpan IntervaloConsulta = TimeSpan.FromSeconds(5);

    // Impede que duas descobertas rodem ao mesmo tempo (inicialização do site + botão da tela Início)
    private static readonly SemaphoreSlim semaforo = new(1, 1);

    public static AwsConfig Config { get; private set; } = new();

    /// <summary>Resultado da última tentativa (exibido na tela Início).</summary>
    public static AwsStatusViewModel Status { get; private set; } = new();

    /// <summary>Caminho completo do arquivo onde devem ser coladas as credenciais do Learner Lab.</summary>
    public static string CaminhoCredenciais { get; private set; } = string.Empty;

    /// <param name="pastaProjeto">Pasta do projeto (ContentRootPath), base do caminho relativo.</param>
    public static void Configura(AwsConfig config, string pastaProjeto)
    {
        Config = config;
        CaminhoCredenciais = Path.GetFullPath(Path.Combine(pastaProjeto, config.ArquivoCredenciais));

        // Faz o próprio AWS SDK usar este arquivo em vez de procurar na pasta do usuário
        AWSConfigs.AWSProfilesLocation = CaminhoCredenciais;

        Status = new AwsStatusViewModel
        {
            Habilitado = config.Habilitado,
            Mensagem = config.Habilitado
                ? "Aguardando a descoberta do IP."
                : "Desativado: usando o Host fixo do appsettings.json."
        };
    }

    /// <summary>
    /// Procura a instância, liga se necessário, espera o IP público e atualiza o Host do FIWARE.
    /// Não lança exceção: o resultado (sucesso ou erro) fica em Status.
    /// </summary>
    public async Task<AwsStatusViewModel> AtualizaIpAsync()
    {
        if (!Config.Habilitado)
            return Status;

        if (!await semaforo.WaitAsync(0))   // já existe uma descoberta em andamento
            return Status;

        try
        {
            Status = new AwsStatusViewModel { Habilitado = true, EmAndamento = true, Mensagem = "Consultando a AWS..." };
            Status = await DescobreIpAsync();

            if (Status.Sucesso)
                HelperFiware.AlteraHost(Status.IpPublico!);
        }
        catch (AmazonServiceException erro)
        {
            Status = Falha(TraduzErroAws(erro));
        }
        catch (Exception erro)
        {
            Status = Falha(erro.Message);
        }
        finally
        {
            semaforo.Release();
        }

        return Status;
    }

    private async Task<AwsStatusViewModel> DescobreIpAsync()
    {
        using var ec2 = new AmazonEC2Client(LeCredenciais(), RegionEndpoint.GetBySystemName(Config.Regiao));
        var limite = DateTime.Now.AddSeconds(Config.TempoEsperaSegundos);
        bool ligadaPeloSite = false;

        while (true)
        {
            var instancia = await ProcuraInstanciaAsync(ec2);
            string estado = instancia.State?.Name?.Value ?? "desconhecido";

            // 1) Ligada e com IP público: pronto
            if (estado == "running" && !string.IsNullOrEmpty(instancia.PublicIpAddress))
            {
                return new AwsStatusViewModel
                {
                    Habilitado = true,
                    Sucesso = true,
                    InstanciaId = instancia.InstanceId,
                    Estado = estado,
                    IpPublico = instancia.PublicIpAddress,
                    LigadaPeloSite = ligadaPeloSite,
                    Mensagem = ligadaPeloSite ? "A instância foi ligada pelo site e o IP foi obtido." : "IP obtido da instância em execução.",
                    AtualizadoEm = DateTime.Now
                };
            }

            // 2) Desligada: pede para a AWS ligar (uma única vez)
            if (estado == "stopped" && !ligadaPeloSite)
            {
                if (!Config.LigarInstancia)
                    return Falha($"A instância {instancia.InstanceId} está desligada e LigarInstancia está desativado.", instancia);

                await ec2.StartInstancesAsync(new StartInstancesRequest { InstanceIds = [instancia.InstanceId] });
                ligadaPeloSite = true;
            }

            if (DateTime.Now > limite)
                return Falha($"Tempo esgotado esperando a instância ligar (estado atual: {estado}).", instancia);

            // 3) Ainda ligando (pending), desligando (stopping) ou sem IP: espera e consulta de novo
            Status = new AwsStatusViewModel
            {
                Habilitado = true,
                EmAndamento = true,
                InstanciaId = instancia.InstanceId,
                Estado = estado,
                LigadaPeloSite = ligadaPeloSite,
                Mensagem = $"Aguardando a instância {instancia.InstanceId} ({estado})..."
            };
            await Task.Delay(IntervaloConsulta);
        }
    }

    /// <summary>Busca a instância pelo Id ou pela tag Name (ignora instâncias encerradas).</summary>
    private static async Task<Instance> ProcuraInstanciaAsync(AmazonEC2Client ec2)
    {
        var requisicao = new DescribeInstancesRequest
        {
            Filters = [new Filter("instance-state-name", ["pending", "running", "stopping", "stopped"])]
        };

        if (!string.IsNullOrWhiteSpace(Config.InstanciaId))
            requisicao.InstanceIds = [Config.InstanciaId];
        else if (!string.IsNullOrWhiteSpace(Config.NomeInstancia))
            requisicao.Filters.Add(new Filter("tag:Name", [Config.NomeInstancia]));
        else
            throw new InvalidOperationException("Informe InstanciaId ou NomeInstancia na seção \"Aws\" do appsettings.json.");

        var resposta = await ec2.DescribeInstancesAsync(requisicao);

        // No AWS SDK v4 as listas vazias chegam como null
        var instancias = (resposta.Reservations ?? []).SelectMany(r => r.Instances ?? []).ToList();
        if (instancias.Count == 0)
            throw new InvalidOperationException(
                $"Nenhuma instância encontrada com o Id/nome configurado na região {Config.Regiao}.");

        // Se houver mais de uma com o mesmo nome, prefere a que já está ligada
        return instancias.FirstOrDefault(i => i.State?.Name?.Value == "running") ?? instancias[0];
    }

    /// <summary>
    /// Lê as credenciais do arquivo a cada tentativa. Assim o site aceita as credenciais
    /// novas de cada sessão do Learner Lab sem precisar ser reiniciado.
    /// Só o arquivo configurado é lido (por padrão, .aws/credentials dentro do projeto).
    /// </summary>
    private static AWSCredentials LeCredenciais()
    {
        if (File.Exists(CaminhoCredenciais) &&
            new CredentialProfileStoreChain(CaminhoCredenciais).TryGetAWSCredentials(Config.Perfil, out var credenciais))
            return credenciais;

        throw new InvalidOperationException(
            $"Credenciais da AWS não encontradas (perfil [{Config.Perfil}]). No Learner Lab, abra " +
            $"AWS Details → AWS CLI → Show e cole o conteúdo em {CaminhoCredenciais}.");
    }

    private static string TraduzErroAws(AmazonServiceException erro) => erro.ErrorCode switch
    {
        "AuthFailure" or "RequestExpired" or "ExpiredToken" or "InvalidClientTokenId" or "UnrecognizedClientException" =>
            "As credenciais da AWS estão vencidas ou inválidas. Copie as novas em AWS Details → AWS CLI → Show " +
            $"para {CaminhoCredenciais} e clique em Atualizar IP pela AWS.",
        "UnauthorizedOperation" =>
            "As credenciais não têm permissão para consultar ou ligar instâncias EC2.",
        "InvalidInstanceID.NotFound" or "InvalidInstanceID.Malformed" =>
            $"A instância {Config.InstanciaId} não existe na região {Config.Regiao}.",
        _ => $"A AWS recusou a operação ({erro.ErrorCode}): {erro.Message}"
    };

    private static AwsStatusViewModel Falha(string mensagem, Instance? instancia = null) => new()
    {
        Habilitado = true,
        Sucesso = false,
        InstanciaId = instancia?.InstanceId,
        Estado = instancia?.State?.Name?.Value,
        Mensagem = mensagem,
        AtualizadoEm = DateTime.Now
    };
}
