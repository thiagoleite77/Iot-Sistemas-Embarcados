namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Dispositivo (ESP32) provisionado no IoT Agent. Id = device_id.
/// </summary>
public class DispositivoViewModel : PadraoViewModel
{
    public string EntityName { get; set; } = string.Empty;
    public string EntityType { get; set; } = string.Empty;
    public string Protocolo { get; set; } = "PDI-IoTA-UltraLight";
    public string Transporte { get; set; } = "MQTT";
    public string? Timezone { get; set; } = "America/Sao_Paulo";

    /// <summary>
    /// API Key do Service Group (a mesma do tópico MQTT /apikey/device_id/attrs).
    /// Sem ela, o IoT Agent não reconhece as mensagens do ESP32.
    /// </summary>
    public string? Apikey { get; set; }
    public List<AtributoViewModel> Atributos { get; set; } = [];

    /// <summary>Comandos separados por vírgula (ex.: "reset, sync").</summary>
    public string? Comandos { get; set; }

    /// <summary>Usado apenas na inclusão: cria a assinatura que grava o histórico no STH-Comet.</summary>
    public bool CriarAssinaturaSth { get; set; } = true;

    public string ProtocoloResumido => Protocolo.Replace("PDI-IoTA-", string.Empty);
}
