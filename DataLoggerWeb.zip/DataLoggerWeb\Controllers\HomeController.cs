using System.Diagnostics;
using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

public class HomeController : Controller
{
    public async Task<IActionResult> Index()
    {
        // Health check dos componentes e totais cadastrados, tudo em paralelo
        var componentes = new StatusDAO().VerificaComponentesAsync();
        var dispositivos = ContaAsync(new DispositivoDAO());
        var servicos = ContaAsync(new ServicoDAO());
        var assinaturas = ContaAsync(new AssinaturaDAO());

        var model = new HomeViewModel
        {
            Aws = AwsDAO.Status,
            Componentes = await componentes,
            QtdDispositivos = await dispositivos,
            QtdServicos = await servicos,
            QtdAssinaturas = await assinaturas
        };
        return View(model);
    }

    /// <summary>
    /// Botão "Atualizar IP pela AWS": inicia a descoberta em segundo plano e volta para a tela Início,
    /// que se recarrega sozinha até a consulta terminar.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult AtualizaIpAws()
    {
        _ = new AwsDAO().AtualizaIpAsync();
        return RedirectToAction(nameof(Index));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel("Ocorreu um erro inesperado.")
        {
            RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
        });

    /// <summary>Total de registros de um recurso (null se o componente estiver fora do ar).</summary>
    private static async Task<int?> ContaAsync<T>(PadraoDAO<T> dao) where T : PadraoViewModel
    {
        try
        {
            return (await dao.ListagemAsync()).Count;
        }
        catch (FiwareException)
        {
            return null;
        }
    }
}
