using System.Text.Json.Nodes;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// DAO genérico com o CRUD comum a todos os recursos do FIWARE.
/// Cada DAO filho informa a URL do recurso e como converter JSON <-> ViewModel
/// (equivalente ao MontaModel / CriaParametros do DAO de banco de dados).
/// </summary>
public abstract class PadraoDAO<T> where T : PadraoViewModel
{
    /// <summary>URL base do recurso. Ex.: http://ip:4041/iot/devices</summary>
    protected abstract string Url { get; }

    /// <summary>Converte um registro JSON retornado pela API em ViewModel.</summary>
    protected abstract T MontaModel(JsonNode registro);

    /// <summary>Converte o ViewModel no JSON esperado pela API.</summary>
    protected abstract JsonObject CriaJson(T model);

    /// <summary>Localiza a lista de registros dentro da resposta da listagem.</summary>
    protected virtual JsonArray? ExtraiLista(JsonNode? resposta) => resposta as JsonArray;

    protected virtual string UrlRegistro(string id) => $"{Url}/{Uri.EscapeDataString(id)}";

    public virtual async Task<List<T>> ListagemAsync()
    {
        var resposta = await HelperFiware.GetAsync($"{Url}?limit=1000");
        return ExtraiLista(resposta)?.OfType<JsonNode>().Select(MontaModel).ToList() ?? [];
    }

    public virtual async Task<T?> ConsultaAsync(string id)
    {
        var registro = await HelperFiware.GetAsync(UrlRegistro(id), nullSeNaoEncontrado: true);
        return registro == null ? null : MontaModel(registro);
    }

    public virtual Task InsertAsync(T model) => HelperFiware.PostAsync(Url, CriaJson(model));

    public abstract Task UpdateAsync(T model);

    public virtual Task DeleteAsync(string id) => HelperFiware.DeleteAsync(UrlRegistro(id));
}
