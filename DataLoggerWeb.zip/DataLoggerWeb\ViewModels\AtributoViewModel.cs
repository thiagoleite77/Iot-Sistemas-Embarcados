namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Atributo medido pelo dispositivo.
/// ObjectId = chave curta enviada pelo firmware (ex.: "t")
/// Nome     = nome do atributo na entidade do Orion (ex.: "temperatura")
/// </summary>
public class AtributoViewModel
{
    public static readonly string[] Tipos = ["Float", "Integer", "Number", "Text", "Boolean"];

    public string ObjectId { get; set; } = string.Empty;
    public string Nome { get; set; } = string.Empty;
    public string Tipo { get; set; } = "Float";
}
