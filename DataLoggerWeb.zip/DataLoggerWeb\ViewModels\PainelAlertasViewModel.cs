namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Situações possíveis de uma grandeza no painel de alertas.
/// </summary>
public static class SituacaoAlerta
{
    public const string SemDados = "sem-dados";
    public const string Normal = "normal";
    public const string Abaixo = "abaixo";
    public const string Acima = "acima";
}

/// <summary>
/// Dados do painel de alertas (devolvidos em JSON para o dashboard).
/// </summary>
public class PainelAlertasViewModel
{
    /// <summary>Quantidade de leituras usadas no cálculo da média.</summary>
    public int JanelaMedia { get; set; }

    /// <summary>Situação de cada grandeza, da maior para a menor prioridade.</summary>
    public List<GrandezaAlertaViewModel> Grandezas { get; set; } = [];

    /// <summary>Grandeza fora do limite com a maior prioridade (null = tudo normal).</summary>
    public GrandezaAlertaViewModel? AlertaAtivo { get; set; }

    /// <summary>Leituras recentes fora do limite, da mais nova para a mais antiga.</summary>
    public List<OcorrenciaAlertaViewModel> Ocorrencias { get; set; } = [];

    /// <summary>Nome do comando de alerta (ex.: "alerta").</summary>
    public string ComandoAlerta { get; set; } = string.Empty;

    /// <summary>true quando o dispositivo tem o comando de alerta cadastrado.</summary>
    public bool ComandoDisponivel { get; set; }

    /// <summary>
    /// Código que deve estar ativo no ESP32: o da grandeza fora do limite com maior
    /// prioridade, ou o código normal (LED e buzzer desligados).
    /// </summary>
    public int CodigoComando { get; set; }

    /// <summary>true quando os botões "Testar alerta" devem aparecer.</summary>
    public bool BotoesTeste { get; set; }
}

public class GrandezaAlertaViewModel
{
    public string Atributo { get; set; } = string.Empty;
    public string Rotulo { get; set; } = string.Empty;
    public string Unidade { get; set; } = string.Empty;
    public double Minimo { get; set; }
    public double Maximo { get; set; }
    public int Prioridade { get; set; }

    /// <summary>Código enviado ao ESP32 quando esta grandeza é o alerta ativo.</summary>
    public int CodigoAlerta { get; set; }

    /// <summary>Valor gravado pelo botão "Testar alerta".</summary>
    public double ValorTeste { get; set; }

    /// <summary>Média das leituras da janela (null quando ainda não há leituras).</summary>
    public double? Media { get; set; }

    /// <summary>Quantidade de leituras que entraram na média.</summary>
    public int Leituras { get; set; }

    public string Situacao { get; set; } = SituacaoAlerta.SemDados;
    public string Mensagem { get; set; } = string.Empty;

    public bool EmAlerta => Situacao is SituacaoAlerta.Abaixo or SituacaoAlerta.Acima;
}

public record OcorrenciaAlertaViewModel(string DataHora, string Rotulo, string Valor, string Situacao);
