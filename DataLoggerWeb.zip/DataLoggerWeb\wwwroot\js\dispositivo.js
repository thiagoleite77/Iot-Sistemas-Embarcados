// Tabela dinâmica de atributos do formulário de dispositivo
$(function () {
    const $corpo = $('#tabelaAtributos tbody');

    $('#btnAdicionarAtributo').on('click', function () {
        const novaLinha = document.getElementById('modeloLinhaAtributo').content.cloneNode(true);
        $corpo.append(novaLinha);
        renumera();
        $corpo.find('tr:last input:first').trigger('focus');
    });

    $corpo.on('click', '.btn-remover', function () {
        $(this).closest('tr').remove();
        renumera();
    });

    // O model binding do ASP.NET exige índices sequenciais: Atributos[0], Atributos[1], ...
    function renumera() {
        $corpo.find('tr').each(function (indice) {
            $(this).find('[name]').each(function () {
                this.name = this.name.replace(/Atributos\[\d+\]/, 'Atributos[' + indice + ']');
                this.id = this.name.replace(/[\[\].]/g, '_');
            });
        });
    }
});
