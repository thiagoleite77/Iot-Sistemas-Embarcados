namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Classe base de todos os ViewModels que possuem CRUD.
/// No FIWARE os identificadores são textos (ex.: "datalogger001").
/// </summary>
public abstract class PadraoViewModel
{
    public string Id { get; set; } = string.Empty;
}
