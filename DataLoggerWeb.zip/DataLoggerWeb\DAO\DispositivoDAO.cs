using System.Text.Json.Nodes;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// CRUD de dispositivos no IoT Agent (/iot/devices).
/// Ao provisionar um dispositivo, o IoT Agent cria a entidade correspondente no Orion.
/// </summary>
public class DispositivoDAO : PadraoDAO<DispositivoViewModel>
{
    protected override string Url => $"{HelperFiware.UrlIoTAgent}/iot/devices";

    protected override JsonArray? ExtraiLista(JsonNode? resposta) => resposta?["devices"] as JsonArray;

    protected override DispositivoViewModel MontaModel(JsonNode registro) => new()
    {
        Id = registro.Texto("device_id"),
        EntityName = registro.Texto("entity_name"),
        EntityType = registro.Texto("entity_type"),
        Protocolo = registro.Texto("protocol"),
        Transporte = registro.Texto("transport"),
        Timezone = registro.Texto("timezone"),
        Apikey = registro.Texto("apikey"),
        Atributos = registro.Lista("attributes").Select(a => new AtributoViewModel
        {
            Nome = a.Texto("name"),
            ObjectId = a.Texto("object_id") is { Length: > 0 } objectId ? objectId : a.Texto("name"),
            Tipo = a.Texto("type")
        }).ToList(),
        Comandos = string.Join(", ", registro.Lista("commands").Select(c => c.Texto("name")))
    };

    /// <summary>JSON da inclusão (POST /iot/devices).</summary>
    protected override JsonObject CriaJson(DispositivoViewModel model)
    {
        var json = CriaJsonAlteracao(model);
        json["device_id"] = model.Id;
        json["protocol"] = model.Protocolo;
        return json;
    }

    /// <summary>JSON da alteração (PUT /iot/devices/id): device_id e protocol não podem ser alterados.</summary>
    private static JsonObject CriaJsonAlteracao(DispositivoViewModel model)
    {
        var json = new JsonObject
        {
            ["entity_name"] = model.EntityName,
            ["entity_type"] = model.EntityType,
            ["transport"] = model.Transporte,
            ["attributes"] = new JsonArray(model.Atributos.Select(a => (JsonNode?)new JsonObject
            {
                ["object_id"] = a.ObjectId,
                ["name"] = a.Nome,
                ["type"] = a.Tipo
            }).ToArray()),
            ["commands"] = new JsonArray(HelperFiware.SeparaLista(model.Comandos).Select(c => (JsonNode?)new JsonObject
            {
                ["object_id"] = c,
                ["name"] = c,
                ["type"] = "command"
            }).ToArray())
        };

        if (!string.IsNullOrWhiteSpace(model.Timezone))
            json["timezone"] = model.Timezone;

        // O IoT Agent procura o dispositivo pelo device_id + apikey do tópico MQTT:
        // sem apikey gravada, as mensagens do ESP32 não são reconhecidas
        if (!string.IsNullOrWhiteSpace(model.Apikey))
            json["apikey"] = model.Apikey;

        return json;
    }

    public override Task InsertAsync(DispositivoViewModel model) =>
        HelperFiware.PostAsync(Url, new JsonObject { ["devices"] = new JsonArray(CriaJson(model)) });

    public override Task UpdateAsync(DispositivoViewModel model) =>
        HelperFiware.PutAsync(UrlRegistro(model.Id), CriaJsonAlteracao(model));

    /// <summary>Exclui o dispositivo do IoT Agent e também a entidade criada no Orion.</summary>
    public override async Task DeleteAsync(string id)
    {
        var dispositivo = await ConsultaAsync(id);
        await base.DeleteAsync(id);

        if (dispositivo != null)
            await new EntidadeDAO().DeleteAsync(dispositivo.EntityName, dispositivo.EntityType);
    }
}
