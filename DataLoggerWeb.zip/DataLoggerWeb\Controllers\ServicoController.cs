using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.Controllers;

public class ServicoController : PadraoController<ServicoViewModel>
{
    public ServicoController() : base(new ServicoDAO()) { }

    protected override ServicoViewModel CriaModelPadrao() => new()
    {
        Cbroker = HelperFiware.Config.UrlOrionInterna,
        EntityType = "Thing",
        Resource = string.Empty
    };

    protected override async Task ValidaDados(ServicoViewModel model, string operacao)
    {
        await base.ValidaDados(model, operacao);

        if (!HelperControllers.UrlValida(model.Cbroker))
            ModelState.AddModelError(nameof(model.Cbroker), "Informe a URL do Orion vista pelo IoT Agent (ex.: http://orion:1026).");

        if (!HelperControllers.IdentificadorValido(model.EntityType))
            ModelState.AddModelError(nameof(model.EntityType), "Informe o tipo padrão das entidades (ex.: Thing).");

        if (!string.IsNullOrEmpty(model.Resource) && !model.Resource.StartsWith('/'))
            ModelState.AddModelError(nameof(model.Resource), "O resource deve começar com / (ex.: /iot/d) ou ficar vazio para MQTT.");
    }
}
