using System.Text.Json.Nodes;
using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Verifica se cada componente do FIWARE está respondendo (health check).
/// </summary>
public class StatusDAO
{
    public async Task<List<FiwareStatusViewModel>> VerificaComponentesAsync()
    {
        var verificacoes = await Task.WhenAll(
            VerificaAsync("Orion Context Broker", $"{HelperFiware.UrlOrion}/version", json => (json?["orion"]).Texto("version")),
            VerificaAsync("IoT Agent MQTT", $"{HelperFiware.UrlIoTAgent}/iot/about", json => json.Texto("version")),
            VerificaAsync("STH-Comet", $"{HelperFiware.UrlSth}/version", json => json.Texto("version")));

        return verificacoes.ToList();
    }

    private static async Task<FiwareStatusViewModel> VerificaAsync(string componente, string url, Func<JsonNode?, string> obtemVersao)
    {
        var status = new FiwareStatusViewModel { Componente = componente, Url = url };
        try
        {
            status.Versao = obtemVersao(await HelperFiware.GetAsync(url));
            status.Online = true;
        }
        catch (Exception erro)
        {
            status.Mensagem = erro.Message;
        }
        return status;
    }
}
