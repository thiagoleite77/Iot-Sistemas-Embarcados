using DataLoggerWeb.DAO;
using DataLoggerWeb.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DataLoggerWeb.Controllers;

public class AssinaturaController : PadraoController<AssinaturaViewModel>
{
    private static readonly string[] Formatos = [AssinaturaDAO.FormatoSth, "normalized", "keyValues"];

    public AssinaturaController() : base(new AssinaturaDAO()) { }

    protected override AssinaturaViewModel CriaModelPadrao() => AssinaturaDAO.NovaAssinaturaHistorico();

    /// <summary>
    /// Cria de uma vez as assinaturas do STH-Comet que faltam para um dispositivo
    /// (uma por atributo). As que já existem são mantidas, para não duplicar o histórico.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CriarParaDispositivo(string id)
    {
        try
        {
            var dispositivo = await new DispositivoDAO().ConsultaAsync(id);
            if (dispositivo == null)
            {
                TempData["Erro"] = $"Dispositivo '{id}' não encontrado.";
                return RedirectToAction(nameof(Index), "Dispositivo");
            }

            var (criadas, existentes) = await new AssinaturaDAO().CriaAssinaturasHistoricoAsync(dispositivo);
            TempData["Sucesso"] = criadas == 0
                ? $"Todos os atributos de {id} já têm assinatura do STH-Comet."
                : $"{criadas} assinatura(s) do STH-Comet criada(s) para {id}" + (existentes > 0 ? $"; {existentes} já existia(m)." : ".");
        }
        catch (Exception erro)
        {
            TempData["Erro"] = erro.Message;
        }
        return RedirectToAction(nameof(Index));
    }

    // O Id da assinatura é gerado pelo Orion, por isso a validação padrão do Id não é usada
    protected override async Task ValidaDados(AssinaturaViewModel model, string operacao)
    {
        ModelState.Clear();

        if (operacao == "A" && (string.IsNullOrWhiteSpace(model.Id) || await DAO.ConsultaAsync(model.Id) == null))
            ModelState.AddModelError(string.Empty, "Assinatura não encontrada no Orion.");

        if (!HelperControllers.TextoValido(model.Descricao))
            ModelState.AddModelError(nameof(model.Descricao), "Informe a descrição (sem os caracteres < > \" ' = ; ( )).");

        if (model.EntidadeId != ".*" && !HelperControllers.IdentificadorValido(model.EntidadeId))
            ModelState.AddModelError(nameof(model.EntidadeId), "Informe o id da entidade (ou .* para todas).");

        if (!HelperControllers.IdentificadorValido(model.EntidadeTipo))
            ModelState.AddModelError(nameof(model.EntidadeTipo), "Informe o tipo da entidade.");

        if (HelperFiware.SeparaLista(model.AtributosCondicao).Any(a => !HelperControllers.IdentificadorValido(a)))
            ModelState.AddModelError(nameof(model.AtributosCondicao), "Lista de atributos inválida.");

        if (HelperFiware.SeparaLista(model.AtributosNotificacao).Any(a => !HelperControllers.IdentificadorValido(a)))
            ModelState.AddModelError(nameof(model.AtributosNotificacao), "Lista de atributos inválida.");

        if (!HelperControllers.UrlValida(model.UrlNotificacao))
            ModelState.AddModelError(nameof(model.UrlNotificacao), "Informe uma URL válida (ex.: http://sth-comet:8666/notify).");

        if (!Formatos.Contains(model.Formato))
            ModelState.AddModelError(nameof(model.Formato), "Formato inválido.");

        // STH-Comet: um atributo por assinatura, e ela dispara só quando esse atributo muda
        if (model.Formato == AssinaturaDAO.FormatoSth)
        {
            var atributos = HelperFiware.SeparaLista(model.AtributosNotificacao);
            if (atributos.Count != 1)
                ModelState.AddModelError(nameof(model.AtributosNotificacao),
                    "Para o STH-Comet, informe exatamente um atributo (crie uma assinatura por atributo).");
            else
                model.AtributosCondicao = atributos[0];

            if (!AtributoViewModel.Tipos.Contains(model.TipoAtributo))
                ModelState.AddModelError(nameof(model.TipoAtributo), "Tipo de atributo inválido.");
        }

        if (model.Status is not ("active" or "inactive"))
            ModelState.AddModelError(nameof(model.Status), "Status inválido.");

        if (model.Throttling < 0)
            ModelState.AddModelError(nameof(model.Throttling), "O throttling não pode ser negativo.");
    }
}
