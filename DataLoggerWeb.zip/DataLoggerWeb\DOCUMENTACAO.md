# Data Logger IoT – Documentação

Aplicação web em **ASP.NET Core 8.0 (MVC)** que consome as APIs do **FIWARE** (Orion Context Broker, IoT Agent MQTT e STH-Comet) para gerenciar e visualizar os dados de um data logger com **ESP32**.

Organização no padrão das aulas: **Controllers**, **ViewModels** e **DAO**. Nesta aplicação o DAO acessa as APIs do FIWARE em vez de um banco SQL.

> Para usar o site sem entrar no código, veja o [MANUAL_CONFIGURACAO.md](MANUAL_CONFIGURACAO.md) (passo a passo e requisitos do ESP32) e o [MANUAL_USO.md](MANUAL_USO.md) (telas).

---

## 1. Estrutura de diretórios

```
DataLoggerWeb/
├── Controllers/
│   ├── PadraoController.cs        ← CRUD genérico (Index, Create, Edit, Save, Delete)
│   ├── HelperControllers.cs       ← validações reaproveitadas
│   ├── HomeController.cs          ← status do FIWARE
│   ├── DispositivoController.cs   ← CRUD de dispositivos + detalhes/comandos
│   ├── ServicoController.cs       ← CRUD de service groups
│   ├── AssinaturaController.cs    ← CRUD de assinaturas
│   ├── ConsultaController.cs      ← consulta de mensagens IoT (Ajax)
│   └── DashboardController.cs     ← dados dos gráficos e do painel de alertas (Ajax)
│
├── DAO/
│   ├── FiwareConfig.cs            ← classe que recebe as configurações
│   ├── HelperFiware.cs            ← faz todas as chamadas HTTP ao FIWARE
│   ├── FiwareException.cs
│   ├── PadraoDAO.cs               ← DAO genérico
│   ├── DispositivoDAO.cs          ← IoT Agent  /iot/devices
│   ├── ServicoDAO.cs              ← IoT Agent  /iot/services
│   ├── AssinaturaDAO.cs           ← Orion      /v2/subscriptions
│   ├── EntidadeDAO.cs             ← Orion      /v2/entities
│   ├── HistoricoDAO.cs            ← STH-Comet  /STH/v1/contextEntities
│   ├── AlertaConfig.cs            ← classe que recebe os limites dos alertas
│   ├── AlertaDAO.cs               ← cálculo das médias × limites (painel de alertas)
│   ├── AwsConfig.cs               ← classe que recebe a seção "Aws"
│   ├── AwsDAO.cs                  ← API do EC2: liga a instância e descobre o IP público
│   └── StatusDAO.cs               ← health check
│
├── ViewModels/
│   ├── PadraoViewModel.cs
│   ├── ErrorViewModel.cs
│   ├── DispositivoViewModel.cs
│   ├── AtributoViewModel.cs
│   ├── AwsStatusViewModel.cs      ← resultado da descoberta do IP na AWS
│   ├── ServicoViewModel.cs
│   ├── AssinaturaViewModel.cs
│   ├── MensagemIoTViewModel.cs
│   ├── ConsultaViewModel.cs
│   ├── DashboardViewModel.cs
│   ├── FiwareStatusViewModel.cs
│   ├── HomeViewModel.cs
│   ├── LimiteViewModel.cs         ← faixa mín/máx e prioridade de uma grandeza
│   └── PainelAlertasViewModel.cs  ← dados do painel de alertas
│
├── Views/
│   ├── _ViewImports.cshtml
│   ├── _ViewStart.cshtml
│   ├── Shared/
│   │   ├── _Layout.cshtml
│   │   ├── _ErrosGerais.cshtml
│   │   ├── Error.cshtml
│   │   └── _ValidationScriptsPartial.cshtml
│   ├── Home/        Index.cshtml
│   ├── Dispositivo/ Index.cshtml, Form.cshtml, Detalhes.cshtml
│   ├── Servico/     Index.cshtml, Form.cshtml
│   ├── Assinatura/  Index.cshtml, Form.cshtml
│   ├── Consulta/    Index.cshtml, pvGridMensagens.cshtml
│   └── Dashboard/   Index.cshtml
│
├── wwwroot/
│   ├── css/site.css
│   ├── js/
│   │   ├── site.js
│   │   ├── dispositivo.js
│   │   ├── consulta.js
│   │   └── dashboard.js
│   ├── lib/                       (bootstrap, jquery, jquery-validation)
│   └── favicon.ico
│
├── .aws/
│   └── credentials                ← CREDENCIAIS DO LEARNER LAB (colar a cada sessão; fora do Git)
│
├── Properties/launchSettings.json
├── appsettings.json               ← CONFIGURAÇÃO DAS APIs, DA AWS E DOS LIMITES DE ALERTA
├── appsettings.Development.json
├── Program.cs
├── DOCUMENTACAO.md                ← este arquivo (visão técnica)
├── MANUAL_CONFIGURACAO.md         ← passo a passo para configurar os dispositivos pelo site
├── MANUAL_USO.md                  ← resumo de cada tela do site
├── .gitignore                     ← impede que .aws, bin e obj vão para o GitHub
└── DataLoggerWeb.csproj
```

---

## 2. Configuração das APIs do FIWARE

O endereço das APIs fica em **`appsettings.json`**, na seção `"Fiware"`. Na prática, é o único arquivo que precisa ser alterado:

```json
"Fiware": {
  "Host": "localhost",
  "PortaOrion": 1026,
  "PortaIoTAgent": 4041,
  "PortaSth": 8666,
  "FiwareService": "smart",
  "FiwareServicePath": "/",
  "TimeoutSegundos": 10,
  "UrlOrionInterna": "http://orion:1026",
  "UrlSthInterna": "http://sth-comet:8666"
}
```

| Campo | O que é |
|---|---|
| `Host` | **IP da máquina ou VM onde o FIWARE roda** (ex.: `"54.123.45.67"`). Normalmente é o único que precisa ser trocado. |
| `PortaOrion` / `PortaIoTAgent` / `PortaSth` | Portas de cada componente. Os valores já são os padrões do FIWARE. |
| `FiwareService` / `FiwareServicePath` | Headers `fiware-service` e `fiware-servicepath` enviados em toda requisição. Precisam ser iguais aos usados pelo firmware e pelo IoT Agent. |
| `TimeoutSegundos` | Tempo máximo de espera por resposta. |
| `UrlOrionInterna` | Endereço do Orion visto **de dentro do docker**. É o valor padrão do campo "cbroker" no cadastro de Service Group. |
| `UrlSthInterna` | Endereço do STH-Comet visto **de dentro do docker**. É usado como URL de notificação das assinaturas. |

### Como a configuração chega no código

1. O `Program.cs` lê a seção `"Fiware"` na inicialização e passa para o `HelperFiware.Configura(...)`.
2. O `DAO/FiwareConfig.cs` é a classe que guarda esses valores.
3. O `DAO/HelperFiware.cs` monta as URLs base (`UrlOrion`, `UrlIoTAgent`, `UrlSth`) e adiciona os headers em toda chamada.
4. Cada DAO só acrescenta o caminho do seu recurso na propriedade `Url`. Por exemplo, o `DispositivoDAO.cs` usa `$"{HelperFiware.UrlIoTAgent}/iot/devices"`.

> Depois de alterar o `appsettings.json`, **reinicie a aplicação** para a configuração ser lida de novo.

### Endpoints do FIWARE usados

| Componente | Endpoint | Uso na aplicação |
|---|---|---|
| IoT Agent | `GET/POST /iot/devices`, `GET/PUT/DELETE /iot/devices/{id}` | CRUD de dispositivos |
| IoT Agent | `GET/POST/PUT/DELETE /iot/services` | CRUD de service groups |
| IoT Agent | `GET /iot/about` | Status |
| Orion | `GET/POST /v2/subscriptions`, `GET/PATCH/DELETE /v2/subscriptions/{id}` | CRUD de assinaturas |
| Orion | `GET /v2/entities/{id}?options=keyValues` | Valores atuais (dashboard e detalhes) |
| Orion | `PATCH /v2/entities/{id}/attrs` | Envio de comandos |
| Orion | `DELETE /v2/entities/{id}` | Remoção da entidade ao excluir o dispositivo |
| Orion | `GET /version` | Status |
| STH-Comet | `GET /STH/v1/contextEntities/type/{tipo}/id/{id}/attributes/{atributo}?lastN=` | Consulta IoT, gráficos e painel de alertas |
| STH-Comet | `GET /version` | Status |

> O STH-Comet devolve **no máximo 100 leituras por consulta** (`lastN`). Por isso a Consulta IoT e o Dashboard aceitam até 100 leituras por atributo. Na Consulta com "Todos", isso dá até 300 linhas para o data logger.

### API Key do dispositivo e autoprovisionamento
Quando chega uma mensagem MQTT em `/<apikey>/<device_id>/attrs`, o IoT Agent (iotagent-node-lib 4.7) procura o dispositivo por `device_id` **e** `apikey`. Um dispositivo gravado sem `apikey` **não é encontrado**:
- com o autoprovisionamento ligado, o IoT Agent cria **outro** dispositivo com o mesmo ID e uma entidade diferente (`<tipo>:<device_id>`), e as leituras vão para ela;
- com o autoprovisionamento desligado, as mensagens são descartadas.

Por isso o site:
- exige a **API Key** no cadastro do dispositivo (lista dos Service Groups) e envia o campo `apikey` ao IoT Agent, também na alteração;
- cria e salva os Service Groups com **`autoprovision: false`**, como no FIWARE Made Simple;
- mostra o selo **sem API Key** na lista e um aviso na tela Detalhes para dispositivos antigos. Basta alterar e escolher a API Key.

### Assinaturas do STH-Comet (histórico)

A plataforma usada no projeto ([FIWARE Made Simple](https://github.com/fabiocabrini/fiware-made-simple)) usa o **Orion 4.5**, que não aceita mais o formato `"attrsFormat": "legacy"`. Como o STH-Comet só entende o formato antigo (NGSIv1), o site cria as assinaturas do mesmo jeito que o passo 2.6 da coleção do Postman:

- **Uma assinatura por atributo.** Para o data logger são três: temperatura, umidade e luminosidade. Colocar dois atributos na mesma assinatura gravaria valores repetidos e distorceria as médias.
- **Notificação `httpCustom`** para `http://sth-comet:8666/notify`, com o corpo NGSIv1 montado pelo site. O Orion troca `${id}`, `${type}` e `${atributo}` pelos valores reais a cada leitura.

Como isso aparece no site:
- **Cadastro de dispositivo:** com a opção marcada, o site cria sozinho as assinaturas de todos os atributos.
- **Botão do sino** na lista de dispositivos: cria só as assinaturas que faltam. As que já existem são mantidas, para não duplicar o histórico.
- **Nova assinatura manual:** no formato **STH-Comet (histórico)**, informe um único atributo e o tipo dele. Os formatos `normalized` e `keyValues` servem para outros destinos e aceitam vários atributos.

---

## 3. Painel de alertas

O **Dashboard** tem um painel que compara a média das leituras mais recentes de cada grandeza com uma faixa permitida (mínimo e máximo). Ele é atualizado junto com o dashboard, a cada 10 s, sem recarregar a página.

### Como funciona
1. O `DashboardController.ObtemAlertas` recebe o dispositivo escolhido (chamada Ajax feita pelo `wwwroot/js/dashboard.js`).
2. O `DAO/AlertaDAO.cs` busca no STH-Comet as últimas leituras de cada grandeza que tem limite configurado (uma consulta por grandeza, em paralelo).
3. Para cada grandeza, calcula a **média das últimas `JanelaMedia` leituras** e compara com a faixa: abaixo do mínimo, acima do máximo, normal ou sem dados.
4. Se mais de uma grandeza estiver fora da faixa, o **alerta ativo** é a de menor número de `Prioridade` (1 = mais importante). As demais aparecem como "também fora do limite".
5. A tabela **Últimas leituras fora do limite** lista até 10 leituras individuais fora da faixa, entre as `LeiturasOcorrencias` mais recentes.

### Envio automático do alerta ao ESP32
Com o **Dashboard aberto** e a chave **"Enviar o alerta ao ESP32 automaticamente"** ligada (padrão), o site envia o comando `alerta` sozinho:

1. A cada atualização do painel (10 s), o `AlertaDAO.cs` calcula o **código que deve estar ativo** (`CodigoComando`): o `CodigoAlerta` do alerta ativo (a grandeza fora do limite com maior prioridade) ou o `CodigoNormal` quando tudo está dentro dos limites.
2. O `wwwroot/js/dashboard.js` compara com o último código enviado para aquele dispositivo e, **se mudou**, chama `DashboardController.EnviaAlerta`. Ele envia o comando pelo Orion e o ESP32 recebe, por exemplo, `env001@alerta|2`.
3. Mesmo sem mudança, o código é **reenviado a cada 60 s**, para o ESP32 voltar ao estado certo se tiver reiniciado.
4. A linha ao lado da chave mostra o último envio (ex.: "Último envio: env001@alerta|2 às 12:49:41").

Cuidados:
- O envio só acontece **com o Dashboard aberto**. Fechando a página, o ESP32 fica com o último código recebido.
- O dispositivo precisa ter o comando `alerta` cadastrado; se não tiver, o painel avisa e não envia nada.
- O `EnviaAlerta` só aceita os códigos configurados (`CodigoNormal` e os `CodigoAlerta`) e exige o token antiforgery.
- O alerta também pode ser enviado manualmente na tela **Detalhes do dispositivo** (veja abaixo).

### Botões "Testar alerta" (para a apresentação)
Com `"BotoesTeste": true`, cada card de grandeza do painel ganha um botão **Testar alerta**. Ao clicar:

1. O `DashboardController.SimulaAlerta` chama o `AlertaDAO.SimulaForaDoLimiteAsync`, que grava no Orion **uma leitura de `ValorTeste` para cada posição da janela da média** (10 leituras, com 150 ms entre elas). A gravação usa `POST /v2/entities/{id}/attrs`, como se o valor viesse do ESP32. Os valores alternam levemente (ex.: 40 e 40,1) para cada um gerar uma notificação ao STH-Comet.
2. Na próxima atualização, a média fica fora da faixa, o painel entra em alerta e o **envio automático** manda o código ao ESP32 (LED e buzzer).
3. **Com o ESP32 ligado**, as leituras reais (a cada 5 s) vão substituindo as de teste: em cerca de 30–40 s a média volta ao normal e o dashboard envia **0**. Isso mostra as duas transições na apresentação. Sem o ESP32 enviando, o alerta continua até chegarem leituras normais.

Cuidados:
- As leituras de teste são **dados de verdade** no Orion e no STH-Comet: aparecem nos cards, nos gráficos e na Consulta IoT.
- Se `ValorTeste` estiver dentro da faixa, o botão avisa e não grava nada.
- Para esconder os botões depois da apresentação, use `"BotoesTeste": false` e reinicie o site.

### Comando de alerta para o ESP32
O firmware trata o comando `alerta` com um valor: o ESP32 recebe `<device_id>@alerta|N`.

| Valor (N) | O que o ESP32 sinaliza |
|---|---|
| 0 | Normal: LED e buzzer desligados |
| 1 | Temperatura fora do limite |
| 2 | Umidade fora do limite |
| 3 | Luminosidade fora do limite |

Na tela **Detalhes do dispositivo**, o comando `alerta` tem um seletor com esses valores e um **índice** mostrando o que cada um significa e a faixa normal de cada grandeza. Os códigos vêm do `appsettings.json` (`CodigoNormal` e `CodigoAlerta`) e precisam ser iguais aos do firmware. Outros comandos aceitam um valor livre (letras, números, `.`, `-` e `_`; os caracteres `|` e `@` são recusados porque são separadores do UltraLight).

### Configuração dos limites (`appsettings.json`, seção `"Alertas"`)

```json
"Alertas": {
  "JanelaMedia": 10,
  "LeiturasOcorrencias": 50,
  "ComandoAlerta": "alerta",
  "CodigoNormal": 0,
  "BotoesTeste": true,
  "Limites": [
    { "Atributo": "temperatura", "Rotulo": "Temperatura", "Unidade": "°C", "Minimo": 15, "Maximo": 30, "Prioridade": 1, "CodigoAlerta": 1, "ValorTeste": 40 },
    { "Atributo": "umidade", "Rotulo": "Umidade", "Unidade": "%", "Minimo": 30, "Maximo": 70, "Prioridade": 2, "CodigoAlerta": 2, "ValorTeste": 85 },
    { "Atributo": "luminosidade", "Rotulo": "Luminosidade", "Unidade": "%", "Minimo": 20, "Maximo": 80, "Prioridade": 3, "CodigoAlerta": 3, "ValorTeste": 95 }
  ]
}
```

| Campo | O que é |
|---|---|
| `JanelaMedia` | Quantas leituras mais recentes entram na média. |
| `LeiturasOcorrencias` | Quantas leituras recentes são analisadas para a tabela de ocorrências. |
| `Atributo` | Nome do atributo no Orion. **Precisa ser igual ao nome cadastrado no dispositivo.** |
| `Rotulo` / `Unidade` | Como a grandeza aparece na tela. |
| `Minimo` / `Maximo` | Faixa considerada normal. Os valores atuais são exemplos e devem ser definidos pela equipe. |
| `Prioridade` | Ordem de importância quando há mais de um alerta (1 = maior). |
| `ComandoAlerta` | Nome do comando de alerta cadastrado no dispositivo (igual ao firmware). |
| `CodigoNormal` | Valor do comando que desliga o alerta (no firmware, `0`). |
| `CodigoAlerta` | Valor do comando que sinaliza esta grandeza no ESP32 (no firmware: 1, 2 e 3). |
| `BotoesTeste` | `true` mostra os botões "Testar alerta" no painel; `false` esconde e bloqueia o teste. |
| `ValorTeste` | Valor fora da faixa gravado pelo botão "Testar alerta" desta grandeza. |

> Depois de alterar os limites, **reinicie a aplicação**.

---

## 4. IP automático pela API da AWS

No AWS Learner Lab, o IP público da EC2 muda a cada Start Lab. Para não precisar copiar o IP do console, o site usa a **API do EC2** (pacote NuGet `AWSSDK.EC2`, versão 4.0.131) assim que inicia:

1. Lê as credenciais temporárias do Learner Lab no arquivo **`.aws/credentials` dentro da pasta do projeto**. Ele não procura na pasta do usuário do Windows.
2. Procura a instância pelo `InstanciaId` ou pela tag `Name` (`DescribeInstances`).
3. Se ela estiver desligada, pede para ligar (`StartInstances`) e consulta de novo a cada 5 s até ficar `running` e ter IP público.
4. Usa o IP encontrado como `Host` do FIWARE, no lugar do valor do `appsettings.json`.

A descoberta roda em segundo plano, então o site abre na hora. O andamento aparece num card no topo da tela **Início**, que se recarrega sozinha até terminar. O botão **Atualizar IP pela AWS** repete a consulta a qualquer momento. As credenciais são relidas do arquivo a cada consulta, então não é preciso reiniciar o site depois de colar credenciais novas.

Se algo falhar (credenciais vencidas, instância não encontrada, sem internet), o card mostra o motivo e o site continua usando o último endereço conhecido.

### Passo a passo a cada sessão do Learner Lab
1. Na página do Learner Lab, clique em **Start Lab** e espere o indicador ficar verde.
2. Clique em **AWS Details → AWS CLI → Show** e copie o bloco inteiro:
   ```
   [default]
   aws_access_key_id=ASIA...
   aws_secret_access_key=...
   aws_session_token=...
   ```
3. No Visual Studio, abra **`.aws/credentials`** no Gerenciador de Soluções, apague todo o conteúdo, cole o bloco e salve. O arquivo já vem no projeto com instruções e não tem extensão.
4. Abra o site (F5). Se ele já estiver aberto, clique em **Atualizar IP pela AWS** na tela Início.

> As credenciais expiram no fim da sessão (cerca de 4 h). A pasta `.aws` está no `.gitignore` e **nunca deve ir para o GitHub**. Ela também não é copiada para a pasta `bin` nem servida pelo site.

### Configuração (`appsettings.json`, seção `"Aws"`)

```json
"Aws": {
  "Habilitado": true,
  "Regiao": "us-east-1",
  "ArquivoCredenciais": ".aws/credentials",
  "Perfil": "default",
  "InstanciaId": "",
  "NomeInstancia": "fiware",
  "LigarInstancia": true,
  "TempoEsperaSegundos": 180
}
```

| Campo | O que é |
|---|---|
| `Habilitado` | `false` desliga a descoberta e o site usa o `Host` fixo da seção `"Fiware"` (útil para testar com o FIWARE local). |
| `Regiao` | Região da EC2. O Learner Lab usa `us-east-1`. |
| `ArquivoCredenciais` | Arquivo das credenciais, relativo à pasta do projeto (ou um caminho completo). Padrão: `.aws/credentials`. |
| `Perfil` | Perfil do arquivo de credenciais. O bloco copiado do Learner Lab é o `[default]`. |
| `InstanciaId` | Id da EC2 (ex.: `i-0abc1234def567890`). Se preenchido, tem prioridade sobre o nome. |
| `NomeInstancia` | Valor da tag `Name` da EC2, ou seja, o nome dado a ela no console. |
| `LigarInstancia` | Se `true`, o site liga a instância quando ela estiver desligada. |
| `TempoEsperaSegundos` | Tempo máximo esperando a instância ligar e receber o IP. |

> O IP descoberto vale só para o site. O ESP32 continua precisando do IP configurado no firmware.

---

## 5. Funcionalidades (requisitos do trabalho)

| Requisito | Onde está |
|---|---|
| CRUDs no FIWARE via API | Menus **Dispositivos**, **Service Groups** e **Assinaturas** |
| Consulta de mensagens IoT com Ajax | Menu **Consulta IoT** (`ConsultaController` + `wwwroot/js/consulta.js`) |
| 2 gráficos no dashboard | Menu **Dashboard**: linha (histórico) e barras (mín/méd/máx por período) |
| Painel de alertas | Menu **Dashboard**: médias × limites, alerta ativo por prioridade e ocorrências |
| Endereço configurável (Learner Lab) | Tela **Início**: IP descoberto pela API da AWS, com botão para atualizar |

---

## 6. Como executar

1. Abra o `DataLoggerWeb.csproj` no Visual Studio 2022 (com o SDK do .NET 8). O pacote `AWSSDK.EC2` é baixado automaticamente na primeira compilação.
2. Ajuste a seção `"Aws"` do `appsettings.json` com o nome (ou Id) da sua EC2.
3. Clique em Start Lab e cole as credenciais no arquivo `.aws/credentials` do projeto (seção 4).
4. Pressione **F5**.
5. Na tela Início, espere o card da AWS mostrar o IP e confira se Orion, IoT Agent e STH-Comet aparecem **Online**. Logo depois que a EC2 liga, os containers do FIWARE ainda podem levar alguns segundos para responder.

### Fluxo para colocar o ESP32 no ar

1. Cadastre um **Service Group** com a API Key usada pelo firmware (ex.: `TEF`).
2. Cadastre o **Dispositivo** com os atributos que o ESP32 envia e mantenha marcada a opção de assinatura do STH-Comet. O site cria uma assinatura por atributo.
3. No firmware, publique via MQTT no tópico `/<apikey>/<device_id>/attrs` com payload UltraLight (ex.: `t|25.4|h|61|l|720`).
4. Acompanhe as leituras na **Consulta IoT** e no **Dashboard**.

> O Bootstrap Icons e o Chart.js são carregados por CDN, então o navegador precisa de internet.
