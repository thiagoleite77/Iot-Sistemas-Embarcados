namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Dados devolvidos (em JSON) para montar os cards e os gráficos do dashboard.
/// </summary>
public class DashboardViewModel
{
    public List<LeituraAtualViewModel> ValoresAtuais { get; set; } = [];
    public string? AtualizadoEm { get; set; }

    // Gráfico 1 (linha): série temporal do atributo
    public List<string> Rotulos { get; set; } = [];
    public List<double> Valores { get; set; } = [];

    // Gráfico 2 (barras): mínimo / média / máximo por período
    public List<string> RotulosAgrupados { get; set; } = [];
    public List<double> Minimos { get; set; } = [];
    public List<double> Medias { get; set; } = [];
    public List<double> Maximos { get; set; } = [];

    // Estatísticas do período consultado
    public int TotalLeituras { get; set; }
    public double? Minimo { get; set; }
    public double? Media { get; set; }
    public double? Maximo { get; set; }
}

public record LeituraAtualViewModel(string Atributo, string Valor);
