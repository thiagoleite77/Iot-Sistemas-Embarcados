using DataLoggerWeb.ViewModels;

namespace DataLoggerWeb.DAO;

/// <summary>
/// Monta o painel de alertas: busca as últimas leituras de cada grandeza no STH-Comet,
/// calcula a média da janela e compara com os limites do appsettings.json.
/// </summary>
public class AlertaDAO
{
    public static AlertaConfig Config { get; private set; } = new();

    public static void Configura(AlertaConfig config)
    {
        // Garante valores aceitos pelo STH-Comet (lastN entre 1 e o máximo da aplicação)
        config.JanelaMedia = Math.Clamp(config.JanelaMedia, 1, HistoricoDAO.MaximoRegistros);
        config.LeiturasOcorrencias = Math.Clamp(config.LeiturasOcorrencias, 1, HistoricoDAO.MaximoRegistros);
        Config = config;
    }

    private readonly HistoricoDAO historicoDAO = new();

    // Intervalo entre as leituras de teste: cada uma chega ao STH-Comet com horário próprio
    private static readonly TimeSpan IntervaloTeste = TimeSpan.FromMilliseconds(150);

    /// <summary>
    /// Botão "Testar alerta" (apresentação): grava no Orion uma leitura fora da faixa para cada
    /// posição da janela da média, então a média sai do limite na próxima atualização do painel.
    /// Os valores alternam levemente para que cada gravação gere uma notificação ao STH-Comet.
    /// Com o ESP32 ligado, as leituras reais vão substituindo as de teste e o alerta volta ao normal.
    /// </summary>
    /// <returns>Quantidade de leituras gravadas.</returns>
    public async Task<int> SimulaForaDoLimiteAsync(DispositivoViewModel dispositivo, LimiteViewModel limite)
    {
        var atributo = dispositivo.Atributos.First(a => a.Nome == limite.Atributo);
        double passo = atributo.Tipo == "Integer" ? 1 : 0.1;
        var entidadeDAO = new EntidadeDAO();

        for (int i = 0; i < Config.JanelaMedia; i++)
        {
            double valor = limite.ValorTeste + (i % 2 == 0 ? 0 : passo);
            await entidadeDAO.GravaLeituraAsync(dispositivo.EntityName, dispositivo.EntityType, atributo.Nome, atributo.Tipo, valor);
            await Task.Delay(IntervaloTeste);
        }

        return Config.JanelaMedia;
    }

    public async Task<PainelAlertasViewModel> ObtemPainelAsync(DispositivoViewModel dispositivo)
    {
        // Só as grandezas que existem no dispositivo, da maior para a menor prioridade
        var limites = Config.Limites
            .Where(l => dispositivo.Atributos.Any(a => a.Nome == l.Atributo))
            .OrderBy(l => l.Prioridade)
            .ToList();

        // Uma consulta ao STH-Comet por grandeza, todas em paralelo
        int quantidade = Math.Max(Config.JanelaMedia, Config.LeiturasOcorrencias);
        var historicos = await Task.WhenAll(
            limites.Select(l => historicoDAO.ConsultaAsync(dispositivo, l.Atributo, quantidade)));

        var painel = new PainelAlertasViewModel
        {
            JanelaMedia = Config.JanelaMedia,
            ComandoAlerta = Config.ComandoAlerta,
            ComandoDisponivel = HelperFiware.SeparaLista(dispositivo.Comandos).Contains(Config.ComandoAlerta),
            BotoesTeste = Config.BotoesTeste
        };
        var ocorrencias = new List<(DateTime DataHora, OcorrenciaAlertaViewModel Ocorrencia)>();

        for (int i = 0; i < limites.Count; i++)
        {
            var limite = limites[i];
            var leituras = historicos[i]
                .Where(m => m.ValorNumerico.HasValue)
                .OrderByDescending(m => m.DataHora)   // mais recentes primeiro
                .ToList();

            painel.Grandezas.Add(AvaliaGrandeza(limite, leituras));

            // Leituras individuais fora da faixa (histórico de ocorrências)
            ocorrencias.AddRange(leituras
                .Select(m => (Leitura: m, Situacao: limite.Classifica(m.ValorNumerico)))
                .Where(x => x.Situacao != SituacaoAlerta.Normal)
                .Select(x => (x.Leitura.DataHora, new OcorrenciaAlertaViewModel(
                    x.Leitura.DataHora.ToString("dd/MM HH:mm:ss"),
                    NomeExibicao(limite),
                    $"{x.Leitura.ValorNumerico:0.##} {limite.Unidade}",
                    x.Situacao))));
        }

        // A lista já está em ordem de prioridade: o primeiro fora do limite é o alerta ativo
        painel.AlertaAtivo = painel.Grandezas.FirstOrDefault(g => g.EmAlerta);

        // Código que o dashboard envia ao ESP32: o da grandeza de maior prioridade fora do limite,
        // ou o código normal quando está tudo dentro dos limites (desliga LED e buzzer)
        painel.CodigoComando = painel.AlertaAtivo?.CodigoAlerta ?? Config.CodigoNormal;
        painel.Ocorrencias = ocorrencias
            .OrderByDescending(o => o.DataHora)
            .Take(10)
            .Select(o => o.Ocorrencia)
            .ToList();

        return painel;
    }

    /// <summary>Calcula a média das últimas N leituras (janela) e compara com os limites.</summary>
    private static GrandezaAlertaViewModel AvaliaGrandeza(LimiteViewModel limite, List<MensagemIoTViewModel> leituras)
    {
        var janela = leituras.Take(Config.JanelaMedia).Select(m => m.ValorNumerico!.Value).ToList();
        double? media = janela.Count > 0 ? Math.Round(janela.Average(), 2) : null;
        string situacao = limite.Classifica(media);

        return new GrandezaAlertaViewModel
        {
            Atributo = limite.Atributo,
            Rotulo = NomeExibicao(limite),
            Unidade = limite.Unidade,
            Minimo = limite.Minimo,
            Maximo = limite.Maximo,
            Prioridade = limite.Prioridade,
            CodigoAlerta = limite.CodigoAlerta,
            ValorTeste = limite.ValorTeste,
            Media = media,
            Leituras = janela.Count,
            Situacao = situacao,
            Mensagem = situacao switch
            {
                SituacaoAlerta.Acima => $"média acima do máximo de {limite.Maximo:0.##} {limite.Unidade}",
                SituacaoAlerta.Abaixo => $"média abaixo do mínimo de {limite.Minimo:0.##} {limite.Unidade}",
                SituacaoAlerta.Normal => "dentro dos limites",
                _ => "sem leituras no STH-Comet"
            }
        };
    }

    private static string NomeExibicao(LimiteViewModel limite) =>
        string.IsNullOrWhiteSpace(limite.Rotulo) ? limite.Atributo : limite.Rotulo;
}
