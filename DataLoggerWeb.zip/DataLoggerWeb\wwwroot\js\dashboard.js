// Dashboard: cards e gráficos (Chart.js) atualizados via Ajax
$(function () {
    const painel = document.getElementById('painelDashboard');
    if (!painel)
        return; // nenhum dispositivo cadastrado

    const campos = {
        dispositivo: document.getElementById('dashDispositivo'),
        atributo: document.getElementById('dashAtributo'),
        quantidade: document.getElementById('dashQuantidade'),
        agrupamento: document.getElementById('dashAgrupamento'),
        automatico: document.getElementById('dashAutomatico')
    };
    const $aviso = $('#avisoDashboard');
    const formataNumero = n => n === null || n === undefined ? '—' : n.toLocaleString('pt-BR', { maximumFractionDigits: 2 });
    let temporizador = null;

    // Gráfico 1: linha com o histórico do atributo
    const graficoLinha = new Chart(document.getElementById('graficoLinha'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: '', data: [], borderColor: '#0d6efd', backgroundColor: 'rgba(13, 110, 253, .12)',
                fill: true, tension: .3, pointRadius: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { display: false } },
            scales: { x: { ticks: { maxTicksLimit: 8 } } }
        }
    });

    // Gráfico 2: barras com mínimo / média / máximo por período
    const graficoBarras = new Chart(document.getElementById('graficoBarras'), {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                { label: 'Mínimo', data: [], backgroundColor: '#20c997' },
                { label: 'Média', data: [], backgroundColor: '#0d6efd' },
                { label: 'Máximo', data: [], backgroundColor: '#fd7e14' }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } }
        }
    });

    function atualiza() {
        if (!campos.atributo.value)
            return;

        $.ajax({
            url: painel.dataset.url,
            data: {
                dispositivoId: campos.dispositivo.value,
                atributo: campos.atributo.value,
                quantidade: campos.quantidade.value,
                agrupamento: campos.agrupamento.value
            },
            cache: false,
            success: function (dados) {
                if (dados.erro) {
                    HelperUI.mostraErro($aviso, dados.msg);
                    return;
                }
                if (dados.totalLeituras === 0)
                    HelperUI.mostraAviso($aviso, 'Nenhuma leitura numérica no STH-Comet para este atributo. Verifique a assinatura do dispositivo.');
                else
                    $aviso.empty();

                renderizaCards(dados);
                renderizaEstatisticas(dados);
                atualizaGraficos(dados);
            },
            error: function () {
                HelperUI.mostraErro($aviso, 'Falha na comunicação com o servidor.');
            }
        });
    }

    function renderizaCards(dados) {
        const $cards = $('#cardsAtuais').empty();
        dados.valoresAtuais.forEach(function (leitura) {
            const $card = $('<div class="col-6 col-md-3"><div class="card kpi h-100"><div class="card-body">' +
                '<div class="rotulo"></div><div class="valor"></div></div></div></div>');
            $card.find('.rotulo').text(leitura.atributo);
            $card.find('.valor').text(leitura.valor);
            if (leitura.atributo === campos.atributo.value)
                $card.find('.card').addClass('kpi-selecionado');
            $cards.append($card);
        });
        $('#atualizadoEm').text(dados.atualizadoEm ? 'Última leitura: ' + dados.atualizadoEm : 'Sem horário da última leitura');
    }

    function renderizaEstatisticas(dados) {
        $('#estTotal').text(dados.totalLeituras);
        $('#estMinimo').text(formataNumero(dados.minimo));
        $('#estMedia').text(formataNumero(dados.media));
        $('#estMaximo').text(formataNumero(dados.maximo));
    }

    function atualizaGraficos(dados) {
        $('.titulo-atributo').text(campos.atributo.value);

        graficoLinha.data.labels = dados.rotulos;
        graficoLinha.data.datasets[0].data = dados.valores;
        graficoLinha.data.datasets[0].label = campos.atributo.value;
        graficoLinha.update();

        graficoBarras.data.labels = dados.rotulosAgrupados;
        [dados.minimos, dados.medias, dados.maximos].forEach((serie, i) => graficoBarras.data.datasets[i].data = serie);
        graficoBarras.update();
    }

    // ------------------------------------------------------------------
    // Painel de alertas: média da janela de cada grandeza × limites
    // (o cálculo é feito no servidor, em AlertaDAO.cs)
    // ------------------------------------------------------------------
    const textoSituacao = { 'normal': 'Normal', 'acima': 'Acima do limite', 'abaixo': 'Abaixo do limite', 'sem-dados': 'Sem dados' };
    const corSituacao = { 'normal': 'success', 'acima': 'danger', 'abaixo': 'danger', 'sem-dados': 'secondary' };

    function atualizaAlertas() {
        $.ajax({
            url: painel.dataset.urlAlertas,
            data: { dispositivoId: campos.dispositivo.value },
            cache: false,
            success: function (dados) {
                if (dados.erro) {
                    HelperUI.mostraErro($('#alertaStatus'), dados.msg);
                    return;
                }
                renderizaAlertas(dados);
                enviaAlertaSeNecessario(dados);
            },
            error: function () {
                HelperUI.mostraErro($('#alertaStatus'), 'Falha na comunicação com o servidor.');
            }
        });
    }

    function renderizaAlertas(dados) {
        $('#alertaJanela').text(dados.janelaMedia);
        renderizaStatusAlerta(dados);
        renderizaGrandezasAlerta(dados.grandezas, dados.botoesTeste);
        renderizaOcorrencias(dados.ocorrencias);
    }

    // Faixa no topo: alerta de maior prioridade ou "tudo normal"
    function renderizaStatusAlerta(dados) {
        const $status = $('#alertaStatus').empty();
        const ativo = dados.alertaAtivo;

        if (ativo) {
            const outros = dados.grandezas
                .filter(g => g.emAlerta && g.atributo !== ativo.atributo)
                .map(g => g.rotulo);
            const $alerta = $('<div class="alert alert-danger alerta-pulsante mb-3"></div>')
                .append('<i class="bi bi-exclamation-triangle-fill"></i> ')
                .append($('<strong></strong>').text('ALERTA: ' + ativo.rotulo))
                .append(document.createTextNode(' – ' + ativo.mensagem + ' (média ' +
                    formataNumero(ativo.media) + ' ' + ativo.unidade + ')'));
            if (outros.length > 0)
                $alerta.append($('<div class="small mt-1"></div>').text('Também fora do limite: ' + outros.join(', ')));
            $status.append($alerta);
        }
        else if (dados.grandezas.length === 0) {
            $status.append($('<div class="alert alert-secondary mb-3"></div>')
                .text('Nenhum atributo deste dispositivo tem limites configurados no appsettings.json.'));
        }
        else if (dados.grandezas.every(g => g.situacao === 'sem-dados')) {
            $status.append($('<div class="alert alert-secondary mb-3"></div>')
                .text('Ainda não há leituras no STH-Comet para calcular as médias.'));
        }
        else {
            $status.append('<div class="alert alert-success mb-3"><i class="bi bi-check-circle-fill"></i> ' +
                'Todas as grandezas estão dentro dos limites.</div>');
        }
    }

    // Um card por grandeza: média, faixa permitida, situação e (opcional) botão de teste
    function renderizaGrandezasAlerta(grandezas, botoesTeste) {
        const $grandezas = $('#alertaGrandezas').empty();
        grandezas.forEach(function (g) {
            const cor = corSituacao[g.situacao];
            const $card = $('<div class="col-md-4"><div class="card h-100 border-start border-4"><div class="card-body">' +
                '<div class="d-flex justify-content-between align-items-center mb-1">' +
                '<span class="rotulo fw-semibold"></span><span class="badge"></span></div>' +
                '<div class="fs-3 fw-semibold media"></div>' +
                '<div class="small text-muted limites"></div></div></div></div>');

            $card.find('.card').addClass('border-' + cor);
            $card.find('.rotulo').text(g.rotulo + ' · prioridade ' + g.prioridade + ' · código ' + g.codigoAlerta);
            $card.find('.badge').addClass('text-bg-' + cor).text(textoSituacao[g.situacao]);
            $card.find('.media').text(g.media === null ? '—' : formataNumero(g.media) + ' ' + g.unidade);
            $card.find('.limites').text('Faixa: ' + formataNumero(g.minimo) + ' a ' + formataNumero(g.maximo) + ' ' +
                g.unidade + ' · ' + g.leituras + ' leituras na média');

            if (botoesTeste) {
                $('<button type="button" class="btn btn-sm btn-outline-danger mt-2 btn-testar-alerta"></button>')
                    .attr('data-atributo', g.atributo)
                    .attr('title', 'Grava leituras de ' + formataNumero(g.valorTeste) + ' ' + g.unidade + ' no Orion')
                    .html('<i class="bi bi-lightning-charge"></i> Testar alerta')
                    .appendTo($card.find('.card-body'));
            }
            $grandezas.append($card);
        });
    }

    // Tabela com as leituras individuais que saíram da faixa
    function renderizaOcorrencias(ocorrencias) {
        const $ocorrencias = $('#alertaOcorrencias').empty();
        if (ocorrencias.length === 0) {
            $ocorrencias.append('<p class="text-muted small mb-0">Nenhuma leitura fora do limite entre as mais recentes.</p>');
            return;
        }

        const $tabela = $('<table class="table table-sm align-middle mb-0"><thead><tr>' +
            '<th>Data/Hora</th><th>Grandeza</th><th>Valor</th><th>Situação</th></tr></thead><tbody></tbody></table>');
        ocorrencias.forEach(function (o) {
            $('<tr></tr>').append(
                $('<td></td>').text(o.dataHora),
                $('<td></td>').text(o.rotulo),
                $('<td class="fw-semibold"></td>').text(o.valor),
                $('<td></td>').append($('<span class="badge"></span>')
                    .addClass('text-bg-' + corSituacao[o.situacao]).text(textoSituacao[o.situacao]))
            ).appendTo($tabela.find('tbody'));
        });
        $ocorrencias.append($('<div class="table-responsive"></div>').append($tabela));
    }

    // ------------------------------------------------------------------
    // Envio automático do alerta ao ESP32 (comando "alerta" com o código)
    // O servidor (AlertaDAO.cs) já decide o código: o da grandeza de maior
    // prioridade fora do limite, ou o normal. Aqui só enviamos quando o código
    // muda e reforçamos a cada 60 s, caso o ESP32 tenha reiniciado e perdido o estado.
    // ------------------------------------------------------------------
    const REFORCO_MS = 60000;
    const envioAutomatico = document.getElementById('alertaEnvioAuto');
    const tokenAntiforgery = $('#painelDashboard input[name="__RequestVerificationToken"]').val();
    const ultimoEnvio = {};   // por dispositivo: { codigo, quando, mensagem, hora }
    let enviando = false;

    function mostraStatusEnvio(texto) {
        $('#alertaEnvioStatus').text(texto);
    }

    function enviaAlertaSeNecessario(dados) {
        const dispositivo = campos.dispositivo.value;
        const anterior = ultimoEnvio[dispositivo];

        if (!dados.comandoDisponivel) {
            mostraStatusEnvio('Este dispositivo não tem o comando "' + dados.comandoAlerta + '" cadastrado.');
            return;
        }
        if (!envioAutomatico.checked) {
            mostraStatusEnvio('Envio automático desligado.');
            return;
        }

        mostraStatusEnvio(anterior ? 'Último envio: ' + anterior.mensagem + ' às ' + anterior.hora : '');

        const mudou = !anterior || anterior.codigo !== dados.codigoComando;
        const reforco = anterior && Date.now() - anterior.quando >= REFORCO_MS;
        if (enviando || (!mudou && !reforco))
            return;

        enviando = true;
        $.ajax({
            type: 'POST',
            url: painel.dataset.urlEnviaAlerta,
            data: { dispositivoId: dispositivo, codigo: dados.codigoComando },
            headers: { 'RequestVerificationToken': tokenAntiforgery },
            success: function (resposta) {
                if (resposta.erro) {
                    mostraStatusEnvio('Falha ao enviar o alerta: ' + resposta.msg);
                    return;
                }
                ultimoEnvio[dispositivo] = {
                    codigo: dados.codigoComando,
                    quando: Date.now(),
                    mensagem: resposta.mensagem,
                    hora: new Date().toLocaleTimeString('pt-BR')
                };
                mostraStatusEnvio('Último envio: ' + resposta.mensagem + ' às ' + ultimoEnvio[dispositivo].hora);
            },
            error: function () {
                mostraStatusEnvio('Falha na comunicação ao enviar o alerta.');
            },
            complete: function () {
                enviando = false;
            }
        });
    }

    // Ao religar a chave, reavalia na hora (e envia o código atual)
    $(envioAutomatico).on('change', function () {
        delete ultimoEnvio[campos.dispositivo.value];
        atualizaAlertas();
    });

    // ------------------------------------------------------------------
    // Botão "Testar alerta" (apresentação): grava no Orion leituras fora do
    // limite da grandeza e atualiza o painel; o envio automático aciona o ESP32
    // ------------------------------------------------------------------
    $('#alertaGrandezas').on('click', '.btn-testar-alerta', function () {
        const $botao = $(this).prop('disabled', true);
        const $status = $('#alertaTesteStatus').text('Gravando leituras de teste no Orion...');

        $.ajax({
            type: 'POST',
            url: painel.dataset.urlSimula,
            data: { dispositivoId: campos.dispositivo.value, atributo: $botao.data('atributo') },
            headers: { 'RequestVerificationToken': tokenAntiforgery },
            success: function (resposta) {
                if (resposta.erro) {
                    $status.text('Falha no teste: ' + resposta.msg);
                    return;
                }
                $status.text(resposta.msg + ' O alerta aparece em instantes.');
                setTimeout(atualizaTudo, 1500);   // tempo para o STH-Comet receber as notificações
            },
            error: function () {
                $status.text('Falha na comunicação ao executar o teste.');
            },
            complete: function () {
                $botao.prop('disabled', false);
            }
        });
    });

    // Atualiza gráficos/cards e o painel de alertas de uma vez
    function atualizaTudo() {
        atualiza();
        atualizaAlertas();
    }

    function configuraAtualizacaoAutomatica() {
        clearInterval(temporizador);
        if (campos.automatico.checked)
            temporizador = setInterval(atualizaTudo, 10000);
    }

    // Eventos
    $(campos.dispositivo).on('change', function () {
        HelperUI.preencheAtributos(campos.dispositivo, campos.atributo, false);
        atualizaTudo();
    });
    $([campos.atributo, campos.quantidade, campos.agrupamento]).on('change', atualiza);
    $(campos.automatico).on('change', configuraAtualizacaoAutomatica);
    $('#btnAtualizar').on('click', atualizaTudo);

    // Carga inicial (seleciona o dispositivo vindo da tela de detalhes, se houver)
    if (campos.dispositivo.dataset.selecionado)
        campos.dispositivo.value = campos.dispositivo.dataset.selecionado;
    HelperUI.preencheAtributos(campos.dispositivo, campos.atributo, false);
    atualizaTudo();
    configuraAtualizacaoAutomatica();
});
