namespace DataLoggerWeb.ViewModels;

/// <summary>
/// Resultado da descoberta do IP da EC2 pela API da AWS (exibido na tela Início).
/// </summary>
public class AwsStatusViewModel
{
    public bool Habilitado { get; set; }

    /// <summary>true enquanto a consulta (ou a espera pela instância ligar) está acontecendo.</summary>
    public bool EmAndamento { get; set; }

    public bool Sucesso { get; set; }
    public string? InstanciaId { get; set; }

    /// <summary>Estado da instância na AWS: pending, running, stopping ou stopped.</summary>
    public string? Estado { get; set; }

    public string? IpPublico { get; set; }

    /// <summary>true quando foi o próprio site que ligou a instância.</summary>
    public bool LigadaPeloSite { get; set; }

    public string Mensagem { get; set; } = string.Empty;
    public DateTime? AtualizadoEm { get; set; }
}
