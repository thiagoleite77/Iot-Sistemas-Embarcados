using DataLoggerWeb.DAO;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Lê a seção "Fiware" do appsettings.json (IP, portas e headers do FIWARE)
HelperFiware.Configura(builder.Configuration.GetSection("Fiware").Get<FiwareConfig>() ?? new FiwareConfig());

// Lê a seção "Alertas" do appsettings.json (limites de cada grandeza e janela da média)
AlertaDAO.Configura(builder.Configuration.GetSection("Alertas").Get<AlertaConfig>() ?? new AlertaConfig());

// Lê a seção "Aws" (descoberta automática do IP da EC2 no Learner Lab).
// O arquivo de credenciais é procurado a partir da pasta do projeto (ContentRootPath).
AwsDAO.Configura(builder.Configuration.GetSection("Aws").Get<AwsConfig>() ?? new AwsConfig(),
    builder.Environment.ContentRootPath);

var app = builder.Build();

// Assim que o site sobe, liga a EC2 (se preciso) e descobre o IP público em segundo plano,
// sem travar a abertura do site. O andamento aparece na tela Início.
app.Lifetime.ApplicationStarted.Register(() => _ = new AwsDAO().AtualizaIpAsync());

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseRequestLocalization("pt-BR"); // datas e números no padrão brasileiro
app.UseHttpsRedirection();
app.UseStaticFiles();   // arquivos de wwwroot (css, js, lib)
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
